describe('installability', () => {
    beforeEach(() => {
        cy.visit('/');
        cy.waitForAppReadiness();
    });
    
    it('should show when browser prompts for install', async () => {
        cy.window().triggerEvent("beforeinstallprompt");
        cy.get("#app > div.install-pwa-prompt > div > h2")
        .shadow()
        .findByText("Install application");
    });

    it("should not prompt when app is installed while launched", () => {
        cy.window().triggerEvent("appinstalled").wait(100);
        cy.window().triggerEvent("beforeinstallprompt");
        cy.get("app > div.install-pwa-prompt > div > h2").wait(100).should("not.have.attr", "data-presented");
      });

      describe("when launched from a home screen", () => {
        beforeEach(() => {
          cy.visit("/", {
            onBeforeLoad(window) {
              cy.stub(window, "matchMedia")
                .withArgs("(display-mode: standalone)")
                .callsFake(() => ({
                  matches: true,
                  addListener: () => false,
                  removeListener: () => false,
                }));

              window.matchMedia.callThrough();
            },
          });
        });
    
        it("should not prompt", () => {
          cy.window().triggerEvent("beforeinstallprompt");
          //cy.get("ion-toast").wait(100).should("not.have.attr", "data-presented");
        });
      });
    
})
