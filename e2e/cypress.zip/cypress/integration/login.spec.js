describe('test login', () => {


    it("Should parse token from response body and return 200", function () {
     
  
    });
  
    it('try to visit again', () => {
      
      cy.get('#app > header > div > h1').should('have.text', "Create a new report")
    });
  });
  
  describe('visist the stie twice', () => {
    it('try to visit again', () => {
      
      cy.get('#app > header > div > h1').should('have.text', "Create a new report")
    });
  })
  
  