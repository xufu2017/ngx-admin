// ***********************************************************
// This example support/index.js is processed and
// loaded automatically before your test files.
//
// This is a great place to put global configuration and
// behavior that modifies Cypress.
//
// You can change the location of this file or turn off
// automatically serving support files with the
// 'supportFile' configuration option.
//
// You can read more here:
// https://on.cypress.io/configuration
// ***********************************************************

// Import commands.js using ES2015 syntax:
import './commands'

let cookiesCache = {};
Cypress.Cookies.defaults({
    whitelist: "session_id"
  })
const clear = Cypress.LocalStorage.clear

Cypress.LocalStorage.clear = function (keys, ls, rs) {
    // do something with the keys here
    if (keys) {
      return clear.apply(this, arguments)
    }
  
  }
  export function saveCookies() {
      cy.getCookies().then((cookies) => {
          cookies.forEach(({ name, ...rest }) => {
              cookiesCache[name] = {
                  name,
                  ...rest,
              };
          });
      });
  }
  
  export function loadCookies() {
      Object.keys(cookiesCache).forEach((key) => {
          const { name, value, ...rest } = cookiesCache[key];
  
          cy.setCookie(name, value, rest);
      });
  }
  
  before(()=>{
      Cypress.LocalStorage.clear();
      cy.login()
      saveCookies();
  })
  
  beforeEach(() => {
      loadCookies();
      cy.visit(Cypress.env('baseUrl'))
  });
  