import {
    Given, When, And, Then
} from 'cypress-cucumber-preprocessor/steps';

import OffLineSearchPage from './offlinesearchPage'

Given("I search Address", () => {
    OffLineSearchPage.initSearch();
})

When("going offline", () => {
    OffLineSearchPage.goOffline();
})