import {
    HomePage,
    PropertySearch,
    CustomerDetail,
    DampInvestigation,
  } from "../../../pageObjects/elements/PageElements";

  const assertOnline = () => {
    return cy.wrap(window).its('navigator.onLine').should('be.true')
  }

  const assertOffline = () => {
    return cy.wrap(window).its('navigator.onLine').should('be.false')
  }

  const goOffline = () => {
    cy.log('**go offline**')
    .then(() => {
      return Cypress.automation('remote:debugger:protocol',
        {
          command: 'Network.enable',
        })
    })
    .then(() => {
      return Cypress.automation('remote:debugger:protocol',
        {
          command: 'Network.emulateNetworkConditions',
          params: {
            offline: true,
            latency: -1,
            downloadThroughput: -1,
            uploadThroughput: -1,
          },
        })
    })
  }

    const goOnline = () => {
    // disable offline mode, otherwise we will break our tests :)
    cy.log('**go online**')
    .then(() => {
      // https://chromedevtools.github.io/devtools-protocol/1-3/Network/#method-emulateNetworkConditions
      return Cypress.automation('remote:debugger:protocol',
        {
          command: 'Network.emulateNetworkConditions',
          params: {
            offline: false,
            latency: -1,
            downloadThroughput: -1,
            uploadThroughput: -1,
          },
        })
    })
    .then(() => {
      return Cypress.automation('remote:debugger:protocol',
        {
          command: 'Network.disable',
        })
    })
  }
  export default class OffLineSearchPage {
    static initSearch() {

      new HomePage().startBtn().click();
      new PropertySearch().searchTextBox().type("leeds");
      new PropertySearch().searchBtn().click();
      new PropertySearch().serchResult().should("have.length", 8);
     
    }

    static goOffline(){

    }
}