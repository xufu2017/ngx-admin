import {
    Given,When,And,Then
} from 'cypress-cucumber-preprocessor/steps';

import DampInvestigationPage from './dampInspectionPage';

Given('I click  Get Started',()=>{
    DampInvestigationPage.clickStart();
})

When('I search Address',()=>{
    cy.log('property detail')
    DampInvestigationPage.searchProperty();
})

And('I choose property and enter customer details',()=>{
    DampInvestigationPage.fillInCustomerDetails();
})

Then('I Entered Damp attributes',()=>{
    DampInvestigationPage.fillInDampInspectionDetails();
})
