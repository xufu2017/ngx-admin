import {
    HomePage,
    PropertySearch
  } from "../pageObjects/elements/PageElements";
const dampData = require("../pageObjects/damp-locator.json");

const assertOnline = () => {
    return cy.wrap(window).its('navigator.onLine').should('be.true')
  }

  const assertOffline = () => {
    return cy.wrap(window).its('navigator.onLine').should('be.false')
  }

  const goOffline = () => {
    cy.log('**go offline**')
    .then(() => {
      return Cypress.automation('remote:debugger:protocol',
        {
          command: 'Network.enable',
        })
    })
    .then(() => {
      return Cypress.automation('remote:debugger:protocol',
        {
          command: 'Network.emulateNetworkConditions',
          params: {
            offline: true,
            latency: -1,
            downloadThroughput: -1,
            uploadThroughput: -1,
          },
        })
    })
  }

  const goOnline = () => {
    // disable offline mode, otherwise we will break our tests :)
    cy.log('**go online**')
    .then(() => {
      // https://chromedevtools.github.io/devtools-protocol/1-3/Network/#method-emulateNetworkConditions
      return Cypress.automation('remote:debugger:protocol',
        {
          command: 'Network.emulateNetworkConditions',
          params: {
            offline: false,
            latency: -1,
            downloadThroughput: -1,
            uploadThroughput: -1,
          },
        })
    })
    .then(() => {
      return Cypress.automation('remote:debugger:protocol',
        {
          command: 'Network.disable',
        })
    })
  }

// since we are using Chrome debugger protocol API
// we should only run these tests when NOT in Firefox browser
// see https://on.cypress.io/configuration#Test-Configuration
describe('offline mode', { browser: '!firefox' }, () => {
    beforeEach(goOnline)
    afterEach(goOnline)
  
    it('shows network status', () => {
        assertOnline()
      new HomePage().startBtn().click();
      new PropertySearch().searchTextBox().type("leeds");
      new PropertySearch().searchBtn().click();
      new PropertySearch().serchResult().should("have.length", 8);
  
      goOffline()
      assertOffline()
      cy.intercept('**/AddressSearch*', { forceNetworkError: true }).as('users')

      new PropertySearch().searchTextBox().clear().type("bradford");
      new PropertySearch().searchBtn().click();
      new PropertySearch().serchResult().should("have.length", 3);
 
      new PropertySearch().searchTextBox().clear().type("leeds");
      new PropertySearch().searchBtn().click();
      new PropertySearch().serchResult().should("have.length", 8);
      
      goOnline()
      assertOnline()
      new PropertySearch().searchTextBox().clear().type("bradford");
      new PropertySearch().searchBtn().click();
      new PropertySearch().serchResult().should("have.length", 8);

    })
  
  })