const dampData=require("../pageObjects/damp-locator.json")
describe('test basic function', () => {
    it('should be able to return page count', async () => {
        let pages=parseInt(dampData.length /10, 10) + 1;
        cy.log(pages)
    });
});