/// <reference types="cypress" />

/* global expect cypress cy*/

import { beforeEach } from 'mocha';
import data from '../db'

const port = Cypress.env('port');
const url = `http://localhost:${port}`;
const itemsCount = 8;
const item = data.items[2];
const itemToDelete = data.items[3];
const newItem = {
    id: 0,
    name: 'item',
    description: 'item description'
}
const resetData = () => cy.request('Post', `${url}/api/reset`, data);

const containsItems = count => cy.get('.list>name').should('have.length', count);

const itemAreVisible = visible => {
    const val = visible ? '' : 'not.';
    return cy.get('.edit-detail').should(`${val}exists`);
}

//common pattern

context('Items', () => {
    beforeEach(() => {
        resetData().then(() => {
            cy.visit(url);
            cy.get('nav ul.menu a').contains('Items').click();
        })
    });
    after(() => resetData());

    specify(`contains ${item.name}`, () => {
        cy.get('.list>name').contains(item.name)
    })

    specify('contains 8 items', () => {
        containsItems(itemsCount)
    })

    specify(`Deletes ${item.name}`, () => {
        cy.get(`.list .delete-item[data-id=${itemToDelete.id}]`).click();
        cy.get('#modal .modal-yes').click();
        containsItems(itemsCount - 1);
        cy.get(`.list .delete-item[data-id=${itemToDelete.id}]`).should('not.exist')
    })


    context(`${item.name} has been selected`, () => {
        beforeEach(() => {
            cy.get(`.list .edit-item[data-id=${itemToDelete.id}]`).click();
        });

        specify(`Show Details for ${item.name}`, () => {
            const match = new RegExp(item.id);
            itemAreVisible(true);
            cy.get(`.list .edit-item[data-id=${itemToDelete.id}]`)
                .invoke('val')
                .should('match', match)
        })

        specify(`Save Changes ${item.name}`, () => {
            const newDescription = 'new Description';
            itemAreVisible(true);
            cy.get('.edit-item input[name=description]')
                .clear()
                .type(newDescription);

            cy.get('.edit-item input[name=description]')
                .invoke('val')
                .should('not.match', new RegExp(item.description))
                .and('match', new RegExp(newDescription))

            cy.get('.edit-item .save-button').click();
            itemAreVisible(true);

            cy.get('.list .description').contains(newDescription);
            containsItems(itemsCount);
        })

        specify(`Cancel Changes ${item.name}`, () => {
            const newDescription = 'new Description';
            itemAreVisible(true);
            cy.get('.edit-item input[name=description]')
                .clear()
                .type(newDescription);

            cy.get('.edit-item input[name=description]')
                .invoke('val')
                .should('not.match', new RegExp(item.description))
                .and('match', new RegExp(newDescription))

            cy.get('.edit-item .cancel-button').click();
            itemAreVisible(false);

            cy.get('.list .description').contains(item.description);
            containsItems(itemsCount);
        })
    })

    context('Add new Item', () => {
        beforeEach(() => {
            cy.get('.content-container .add-button').click();
        });

        specify(`Save changes to ${newItem}`, () => {
            itemAreVisible(true);
            cy.get('.edit-detail input[name=name]')
                .clear()
                .type(newItem.name)
            cy.get('.edit-detail input[name=description]')
                .clear()
                .type(newItem.description)
            cy.get('.edit-item .save-button').click();
            itemAreVisible(false);
            cy.get('.list .description').contains(newItem.description);
            containsItems(itemsCount + 1);
        })
    })

    context('Direct Routing', () => {
        specify('route to items directly and see items list', () => {
            cy.visit(url)
            cy.wait(1000);
            cy.location().should(loc => {
                expect(loc.host).to.eq(`localhost:${port}`)
                expect(loc.hostname).to.eq('localhost');
                expect(loc.href).to.eq(`${url}/items`);
                expect(loc.origin).to.equal(url);
                expect(loc.port).to.eq(port);
                expect(loc.protocol).to.eq('http:');
                expect(loc.toString()).to.eq(`${url}/items`);
            });
            itemAreVisible(false);
            containsItems(itemsCount);
        })
    })

})