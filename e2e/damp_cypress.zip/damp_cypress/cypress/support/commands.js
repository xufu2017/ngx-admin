
Cypress.Commands.add("login", function () {
    const url = Cypress.env('authorizeUrl')
    const Username = Cypress.env('username')
    const password = Cypress.env('password')
    cy.request(url)
        .then((response) => {
            let body = response.body
            const $html = Cypress.$(body)
            const token = $html.find("input[name=__RequestVerificationToken]").val()
            const cookies = response.headers['set-cookie']
            if (cookies)
                cookies.forEach(cookie => {
                    const firstPart = cookie.split(';')[0]
                    const separator = firstPart.indexOf('=')
                    const name = firstPart.substring(0, separator)
                    const value = firstPart.substring(separator + 1)
                    console.debug('cookie', name, value)
                    cy.setCookie(name, value)
                })
            cy.request({
                method: "POST",
                failOnStatusCode: true,
                url: url,
                form: true,
                body: {
                    Username: Username,
                    password: password,
                    __RequestVerificationToken: token,
                    RememberLogin: true
                }
            }).then((resp) => {
                expect(resp.status).to.eq(200)
            })
        })
})

Cypress.on('uncaught:exception', (err, runnable) => {
    console.log(err);
    return false;
  })
