import Vue from 'vue'
import VueRouter, { RouteConfig } from 'vue-router'
import store from '../store'
import Home from '../views/Home.vue'
import AccessDenied from '../views/AccessDenied.vue'

Vue.use(VueRouter)

const storeRef = store;

const routes: Array<RouteConfig> = [
    {
        path: '/',
        name: 'Home',
        component: Home,
        meta: {
            title: 'Home'
        }
    },
    {
        path: '/test',
        name: 'test',
        component: () => import(/* webpackChunkName: "property" */ '../views/CheckBoxTest.vue'),
        meta: {
            title: 'Checkbox test'
        }
    },
    {
        path: '/access-denied',
        name: 'Access Denied',
        component: AccessDenied,
        meta: {
            title: 'Access Denied'
        }
    },
    {
        path: '/property/:id',
        name: 'Property',
        component: () => import(/* webpackChunkName: "property" */ '../views/Property.vue'),
        meta: {
            title: 'Property'
        }
    },
    {
        path: '/authorisation',
        name: 'Authorisation',
        component: () => import(/* webpackChunkName: "authorisation" */ '../views/Authorisation.vue'),
        meta: {
            title: 'Authorisation'
        },
        beforeEnter: (to, from, next) => {
            if (store.getters["identity/user"].roles.includes('Asset Portal Admin')) next();
            else next("/access-denied");
        }
    },
    {
        path: '/authorisation/:id',
        name: 'AssetUpdate',
        component: () => import(/* webpackChunkName: "authorisation" */ '../views/AssetUpdate.vue'),
        meta: {
            title: 'Asset Update'
        },
        beforeEnter: (to, from, next) => {
            if (store.getters["identity/user"].roles.includes('Asset Portal Admin')) next();
            else next("/access-denied");
        }
    }
]

const router = new VueRouter({
    mode: 'history',
    base: process.env.BASE_URL,
    routes,
    scrollBehavior(to, from, savedPosition) {
        if (savedPosition) {
            return savedPosition
        } else {
            return { x: 0, y: 0 }
        }
    },
})

router.beforeEach(async (to, from, next) => {
    document.title = to.meta.title + " - Assets Portal";

    if (storeRef.getters["navigation/currentNavigationState"] === true) {
        const el = document.body;
        el.classList.remove("navigation-open");

        storeRef.dispatch("navigation/toggleNavigationState");
    }

    next();
});

export default router