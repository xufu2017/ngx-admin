<template>
  <div>
    <base-checkbox-component
      v-for="(option, index) in options"
      v-bind:id="option.attributeLookupValueId"
      v-bind:key="index"
      v-bind:value="option.attributeLookupValueId"
      v-bind:label="option.attributeLookupValueName"
      v-bind:aria-label="option.attributeLookupValueName"
      v-bind:name="name"
      v-bind:checked="checked(option.attributeLookupValueId)"
      v-on:update-item="updateItem($event)"
    />
  </div>
</template>

<script lang="ts">
import { Component, Prop, Vue } from "vue-property-decorator";
import BaseCheckboxComponent from "./BaseCheckboxComponent.vue";
import AttributeLookupValue, {
  RecordAttributeLookupValue,
} from "../../models/attribute-lookup-value";

@Component({
  components: {
    BaseCheckboxComponent,
  },
})
export default class BaseCheckboxGroup extends Vue {

  @Prop({ type: String, default: "" })
  readonly value: string|null|undefined;
  @Prop({ required: true, type: Array, default: [] })
  options: Array<AttributeLookupValue>;
  @Prop({ required: true, type: String, default: "default" })

  readonly name: string;
  _dataArray: Array<number> = [];

  get dataArray(): Array<number> {
    return this._dataArray;
  }
  set dataArray(value: Array<number>) {
    this._dataArray = value;
  }

  created() {
    this._dataArray =
      !this.value
        ? []
        : this.value.split(",").map((x) => parseInt(x, 10));
  }

  checked(checkId: number) {
    return this._dataArray.indexOf(checkId) != -1;
  }

  updateItem(inComing: RecordAttributeLookupValue) {
    if (inComing.selectedValue) {
      this._dataArray.push(inComing.attributeLookupValueId);
    } else {
      this._dataArray.forEach((item, index) => {
        if (item === inComing.attributeLookupValueId)
          this._dataArray.splice(index, 1);
      });
    }
    this.dataArray = this._dataArray;
    this.$emit("input", this._dataArray.join(","));
  }
}
</script>
