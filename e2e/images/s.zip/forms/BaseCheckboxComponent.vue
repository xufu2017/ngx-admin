<template>
  <div>
    <div class="has-checkbox">
      <input
        v-bind:id="name+id"
        type="checkbox"
        v-bind:name="name"
        v-bind:checked="checked"
        v-bind:value="value"
        v-bind:aria-label="label"
        v-on:change="updateCheckbox($event.target.checked)"
      >
      <label v-bind:for="name+id">
        {{ label }}
        <span>  
          <Icon name="check" />
        </span>
      </label>
    </div>
  </div>
</template>

<script lang="ts">
import { Component, Prop, Vue } from "vue-property-decorator";

@Component
export default class BaseCheckboxComponent extends Vue {
  @Prop({ required: true, type: String, default: "nameGoesHere" })
  readonly name!: string;
  @Prop({ required: true, type: String, default: "aria-label" })
  readonly label!: string;
  @Prop({ required: true, default: "" })
  readonly value!: number;
  @Prop({ required: true, type: Number, default: "0" })
  readonly id!: number;
  @Prop({ required: true, type: Boolean, default: false })
  readonly checked!: boolean;
  @Prop({
    required: true,
    type: String,
    default: "Hey Developer provide an aria-label",
  })
  readonly ariaLabel!: string;

  updateCheckbox(checkVal: boolean) {
    this.$emit("update-item", {
      attributeLookupValueId: this.value,
      attributeLookupValueName: this.label,
      selectedValue: checkVal,
    });
  }
}
</script>