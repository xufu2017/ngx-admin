export default {
  stateFormat: function (val) {
    return `${val.name} (${val.abbreviation})`;
  }
}