# Vuex State Management - Pluralsight Course
This is the demo starting point for the Pluralsight [State Management With Vuex](https://www.pluralsight.com/courses/vuex-state-management) course.

