const AssetsPortalRepositoryMock=jest.fn().mockImplementation(()=>{
    return {
        getAssets: jest.fn().mockImplementation(async (parameter ) => Promise.resolve()),
        getComponents: jest.fn().mockImplementation(async (parameter ) => Promise.resolve()),
        getAssetsProperty: jest.fn().mockImplementation(async (parameter ) => Promise.resolve()),
        getComponentAttribute: jest.fn().mockImplementation(async (parameter ) => Promise.resolve()),
    }
})

export default AssetsPortalRepositoryMock;