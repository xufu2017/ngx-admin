import BaseMockStore from './base-mock-store'
import { propertyStore } from '@/store/property-store'
import { AssetSearch } from "@/models/asset-search";


export default class PropertyMockStore extends BaseMockStore {
    _instance = propertyStore;
    constructor() {
        super();
    }
    overrideDefault() {
        const moduleStore = super.overrideDefault();
        moduleStore.state = {
            componentsLoading: true,
            address: "13 Centuary Street Keighley BD21 5DJ",
            componentUpdatesTableHeadings: [
                "Name",
                "Component Type",
            ],
            componentUpdates: [],
            successfullySubmitted: false,
            viewPrompt: "View and update components for this Asset below",
            relevantNotes: "",
            assetsProperty: new AssetSearch(),
        };

        moduleStore.getters = {
            componentUpdates: jest.fn(() => true),
            address: jest.fn(() => ""),
            componentUpdatesTableHeadings: jest.fn(() => ""),
            successfullySubmitted: jest.fn(() => true),
            viewPrompt: jest.fn(() => ""),
            property:jest.fn(() => new AssetSearch()),
        };

        moduleStore.actions = {
            toggleComponentsLoadingState: jest.fn().mockImplementation(() => {
            }),
            updatePropertyAddress: jest.fn().mockImplementation(() => {
            }),
            resetPropertyDetails: jest.fn().mockImplementation(() => {
            }),
            submitComponentUpdates: jest.fn().mockImplementation(() => {
            }),
            updateViewPrompt: jest.fn().mockImplementation(() => {
            }),

            updateRelevantNotes: jest.fn().mockImplementation(() => {
            }),
            resetViewPrompt: jest.fn().mockImplementation(() => {
            }),
            setProperty: jest.fn().mockImplementation(() => {
            }),
        }

        return moduleStore;

    }
}