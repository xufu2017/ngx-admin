import BaseMockStore from './base-mock-store'
import {componentStore} from '@/store/component-store'
import { Component } from '@/models/component';

export default class ComponentMockStore extends BaseMockStore{
    _instance=componentStore;
    constructor() {
        super();
    }
    overrideDefault() {
        const moduleStore = super.overrideDefault();
        moduleStore.state={
            resultsLoading: true,
        componentTableHeadings: [
            "Name",
            "ComponentType"
        ],
        componentList: new Array<Component>()
        };
        moduleStore.getters = {
            resultsLoading: jest.fn(() => true),
            componentTableHeadings: () => ["name","ComponentType"],
            componentList: jest.fn(() => new Array<Component>()),
        };
        moduleStore.actions= {
            setComponentList: jest.fn().mockImplementation(() => {
            }),
        };

        return moduleStore;
    }
}