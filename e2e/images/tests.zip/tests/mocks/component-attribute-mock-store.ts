﻿import BaseMockStore from './base-mock-store'
import { componentAttributeStore } from "../../src/store/component-attribute-store"
import { ComponentAttribute } from "../../src/models/component-attribute"

export default class ComponentAttributeMockStore extends BaseMockStore {
    _instance = componentAttributeStore;
    constructor() {
        super();
    }
    overrideDefault() {
        const moduleStore = super.overrideDefault();
        moduleStore.state = {
            resultsLoading: true,
            componentUpdatesTableHeadings: [
                "Name",
                "Value"
            ],
            componentAttributeResults: new Array<ComponentAttribute>()
        };
        moduleStore.getters = {
            resultsLoading: jest.fn().mockReturnValue(true),
            componentUpdatesTableHeadings: jest.fn().mockReturnValue([
                "Name",
                "Value"
            ]),
            componentAttributeResults: jest.fn().mockReturnValue(new Array<ComponentAttribute>())
        };
        moduleStore.actions = {
            toggleResultsLoadingState: jest.fn(),
            resetPropertySearch: jest.fn(),
            updateSearchResults: jest.fn()
        };
        return moduleStore;
    }
}