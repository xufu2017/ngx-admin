import Axios from "axios";
import MockAdapter from "axios-mock-adapter";
import AssetPortalRepository from "@/repositories/assets-portal-repository";
import { Component } from "@/models/component";
import { AssetSearch } from "@/models/asset-search";

jest.mock("../../../src/utils/identity", () => {
  return jest.fn().mockImplementation(() => {
    return {
      getAccessToken: () => {
        return new Promise((resolve) => {
          resolve("MockAccessToken");
        });
      },
      silentSignIn: () => {
        return new Promise((resolve) => {
          resolve("MockAccessToken");
        });
      },
    };
  });
});
describe("unit test for asset portal repository", () => {
  const repo = new AssetPortalRepository();
  const mockAxios = new MockAdapter(Axios);
  beforeEach(async () => {
    mockAxios.reset();
    jest.clearAllMocks();
  });

  it("can fetch the property result through the property search when result found", async () => {
    let url = "";
    const assetSearchdto = {
      assetId: 0,
      propertyCode: "",
      addressLine1: "",
      addressLine2: "",
      addressLine3: "",
      addressLine4: "",
      postCode: "BD18 1BX",
      propertyType: "",
      neighbourhoodDescription: "",
    };

                const searchList = {
                    TotalItems: 0,
                    ItemsPerPage: 0,
                    CurrentPage: 0,
                    TotalRows: 0,
                    results: [
                        {
                            Id: 673,
                            PropertyCode: "158",
                            AddressLine1: "Leeds Road/hall Lane 140/150-28/50",
                            AddressLine2: "Leeds Road",
                            PostCode: "BD18 1BX",
                            Type: "BLOCK",
                        },
                        {
                            Id: 684,
                            PropertyCode: "159",
                            AddressLine1: "Leeds Road/hall Lane 152/162-52/74",
                            AddressLine2: "Leeds Road",
                            PostCode: "BD18 1BX",
                            Type: "BLOCK",
                        },
                    ],
                };
                mockAxios
                    .onPost(
                        "/Assets/Search?pageNumber=1&pageSize=10",
                        assetSearchdto
                    ).reply(function (config) {
                        url = config.url ? config.url : "";

                        return new Promise(function (resolve) {
                            resolve([
                                200,
                                searchList
                            ]);
                        });
                    })
                const result = await repo.getAssets(assetSearchdto, 1, 10);
                await expect(result.results.length == 2);
                await expect(url).toBe("/Assets/Search?pageNumber=1&pageSize=10");
            });

  it("can retrieve asset component elements", async () => {
    let url = "";
    const componentList = new Array<Component>();
    const componentDto = new Component();
    componentDto.assetId = 1;
    componentDto.componentId = 1;
    componentDto.componentElementId = 1;
    componentDto.name = "test";
    componentDto.componentType = "test";

    componentList.push(componentDto);

    mockAxios
      .onGet("AssetsComponent/ComponentElement/1")
      .reply(function(config) {
        url = config.url ? config.url : "";
        return new Promise(function(resolve) {
          resolve([200, componentList]);
        });
      });

    const result = await repo.getComponents(componentDto.assetId);

    expect(url).toBe("/AssetsComponent/ComponentElement/1");
    expect(result[0].assetId).toBe(1);
  });

  it("can retrieve asset component elements and handle 204", async () => {
    mockAxios.onGet("AssetsComponent/ComponentElement/1").reply(function() {
      return new Promise(function(resolve) {
        resolve([204, []]);
      });
    });

    expect((await repo.getComponents(1)).length).toBe(0);
  });

  it("can retrieve property address", async () => {
    let url = "";
    const propertyAddress = new AssetSearch();
    propertyAddress.assetId = 1;

    mockAxios.onGet("Assets/1").reply(function(config) {
      url = config.url ? config.url : "";
      return new Promise(function(resolve) {
        resolve([200, propertyAddress]);
      });
    });

    const result = await repo.getAssetsProperty(propertyAddress.assetId);

    expect(url).toBe("/Assets/1");
    expect(result.assetId).toBe(1);
  });

        it("can retrieve asset property address and handle 404",
            async () => {
                mockAxios.onGet("Asset/1").reply(function () {
                    return new Promise(function (resolve) {
                        resolve([404]);
                    });
                });
                await expect(repo.getAssetsProperty(1)).rejects.toEqual(
                    new Error("Error: Request failed with status code 404")
                );
            });

        it("can retrieve component element Attributes",
            async () => {
                let url = "";
                const componentAttributeDto = {
                    assetId: 9,
                    componentElementId: 18,
                    attributeDataTypeId: 0,
                    attributeId: 0,
                    componentName: '',
                    attributeName: '',
                    attributeLookupValueName: '',
                    componentElementAttributeValue: '',
                    attributeLookupValueId: '',
                    status: '',
                };
                const componentAttributeList = {
                    results: [
                        {
                            "attributeValueList": null,
                            "componentElementId": null,
                            "componentName": null,
                            "attributeName": null,
                            "attributeDataTypeId": 0,
                            "attributeId": 21,
                            "attributeLookupValueName": "Unknown",
                            "componentElementAttributeValue": null,
                            "attributeLookupValueId": 63,
                            "status": null
                        },
                        {
                            "attributeValueList": null,
                            "componentElementId": null,
                            "componentName": null,
                            "attributeName": null,
                            "attributeDataTypeId": 0,
                            "attributeId": 21,
                            "attributeLookupValueName": "Traditional Bathroom",
                            "componentElementAttributeValue": null,
                            "attributeLookupValueId": 64,
                            "status": null
                        },
                    ],
                };

                mockAxios
                    .onPost(
                        "/ComponentAttributes/ComponentAttribute", componentAttributeDto

                    ).reply(function (config) {
                        url = config.url ? config.url : "";

                        return new Promise(function (resolve) {
                            resolve([
                                200,
                                componentAttributeList
                            ]);
                        });
                    })


                const result = await repo.getComponentAttribute(componentAttributeDto);
                await expect(result.results.length == 2);
                await expect(url).toBe("/ComponentAttributes/ComponentAttribute");
            });

        it("can retrieve component element Attributes and handle 404",
            async () => {
                const componentAttributeDto = {
                    assetId: 9,
                    componentElementId: 18,
                    attributeDataTypeId: 0,
                    attributeId: 0,
                    componentName: '',
                    attributeName: '',
                    attributeLookupValueName: '',
                    componentElementAttributeValue: '',
                    attributeLookupValueId: '',
                    status: '',
                };
                mockAxios.onPost("ComponentAttributes/ComponentAttribute", componentAttributeDto).reply(function () {
                    return new Promise(function (resolve) {
                        resolve([404]);
                    });
                });

                await expect(repo.getComponentAttribute(componentAttributeDto)).rejects.toEqual(
                    new Error("Error: Request failed with status code 404")
                );
            });
    });