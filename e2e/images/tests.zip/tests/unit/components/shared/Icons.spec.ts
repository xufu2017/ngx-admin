import Icon from "@/components/shared/icons.vue";
import { shallowMount } from "@vue/test-utils";
describe('Icons.vue', () => {

    it('It is a vue instance', async () => {
        const wrapper = shallowMount(Icon, {
            propsData: {
              name: "gps",
            },
          });
        expect(wrapper.isVueInstance).toBeTruthy();
    });

    it('renders value when passed', async () => {
        const wrapper = shallowMount(Icon, {
            propsData: {
              name: "logo",
            },
          });
        let svgs = wrapper.find("#logo");
        expect(svgs.exists()).toBe(true);
    });

})