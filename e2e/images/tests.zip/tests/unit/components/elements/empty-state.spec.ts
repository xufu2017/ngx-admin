import { shallowMount } from "@vue/test-utils";
import EmptyState from "@/components/elements/EmptyState.vue";
import Icon from "@/components/shared/Icons.vue"
describe("EmptyState.vue", () => {
  it("It is a vue instance", async () => {
    const component = shallowMount(EmptyState, {
      propsData: {
        icon: "test",
        title: "test_01",
        message: "test",
      },
    });
    expect(component.isVueInstance).toBeTruthy();
    await expect(
      component.findComponent(Icon).exists()
    ).toBeTruthy();
  });

  it("renders value when passed", async () => {
    const component = shallowMount(EmptyState, {
      propsData: {
        icon: "test",
        title: "test title",
        message: "test message",
      },
    });

    const titles = component.findAll("h3");
    await expect(titles.length).toBe(1);
    await expect(titles.at(0).text()).toBe("test title");

    const messageDom = component.find("p");
    await expect(messageDom.text()).toBe("test message");
  });
});
