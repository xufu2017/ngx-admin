import { shallowMount } from "@vue/test-utils";
import Textarea from "@/components/elements/Textarea.vue";
describe("Textarea.vue", () => {
  it("It is a vue instance", async () => {
    const component = shallowMount(Textarea, {
      propsData: {
        label: "TextArea",
        id: "assetarea",
        placeholder: "Enter area e.g BD17 7BN",
        value: "test area",
      },
    });
    expect(component.isVueInstance).toBeTruthy();
  });

  it("renders value when passed", async () => {
    const component = shallowMount(Textarea, {
      propsData: {
        label: "TextArea",
        id: "assetarea",
        placeholder: "Enter area e.g BD17 7BN",
        value: "test area",
      },
    });
    const inputVal = component.find("#assetarea");
    await expect(inputVal.attributes("placeholder")).toBe(
      "Enter area e.g BD17 7BN"
    );
    const label = component.find("label");
    await expect(label.text()).toBe("TextArea");
  });

  it("trigger value changes when passed", async () => {
    const component = shallowMount(Textarea, {
      propsData: {
        label: "TextArea",
        id: "assetarea",
        placeholder: "Enter area e.g BD17 7BN",
        value: "test area",
      },
    });
    const inputVal = component.find("#assetarea");
    inputVal.setValue("text changed");
    expect(component.emitted("input")).toEqual([["text changed"]]);
  });
});
