import { shallowMount } from "@vue/test-utils";
import Input from "@/components/elements/Input.vue";
import Icon from "@/components/shared/Icons.vue"
describe("Input.vue", () => {
  it("It is a vue instance", async () => {
    const component = shallowMount(Input, {
      propsData: {
        id: "assetPostcode",
        placeholder: "Enter postcode e.g BD17 7BN",
        icon: "gps",
        value: "postcode",
      },
    });
    expect(component.isVueInstance).toBeTruthy();
    await expect(
      component.findComponent(Icon).exists()
    ).toBeTruthy();
  });

  it("renders value when passed", async () => {
    const component = shallowMount(Input, {
      propsData: {
        id: "assetPostcode",
        placeholder: "Enter postcode e.g BD17 7BN",
        icon: "gps",
        value: "postcode",
        type: "text",
      },
    });
    const inputVal = component.find("#assetPostcode");
    await expect(inputVal.attributes("placeholder")).toBe(
      "Enter postcode e.g BD17 7BN"
    );
  });

  it("trigger value changes when passed", async () => {
    const component = shallowMount(Input, {
      propsData: {
        id: "assetPostcode",
        placeholder: "Enter postcode e.g BD17 7BN",
        icon: "gps",
        value: "postcode",
        type: "text",
      },
    });
    const inputVal = component.find("#assetPostcode");
    inputVal.setValue("text changed");
    expect(component.emitted("input")).toEqual([["text changed"]]);
  });
});
