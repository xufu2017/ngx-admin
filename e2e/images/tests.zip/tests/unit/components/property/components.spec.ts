import Components from "@/components/property/components.vue";
import Table from "@/components/elements/Table.vue"
import EmptyState from "@/components/elements/EmptyState.vue"
import flushPromises from 'flush-promises';
import { mountComponentWithStore } from "../../../utils";
import AssetsPortalRepositoryMock from '../../../mocks/assets-portal-repository';
import PropertyMockStore from "../../../mocks/property-mock-store";
import ComponentMockStore from "../../../mocks/component-mock-store";

describe('Components.vue', () => {
    let mockStore: any;
    let componentModule: any;
    let propertyModule: any;
    let mocks: any;
    let data: any;
    let componentList: any;

    beforeEach(async () => {
        componentList = Array(40)
            .fill(null)
            .map((v, i) => ({
                assetId: 1,
                componentId: i,
                name: 'component' + i
            }));

        propertyModule = await new PropertyMockStore().getStore();
        componentModule = await new ComponentMockStore().getStore();
        mockStore = {
            modules: {
                property: propertyModule,
                component: componentModule,
            }
        };
        mocks = {
            $route: {
                params: {
                    id: 1
                }
            }
        };
        data = () => {
            return {
                assetsPortalRepository: AssetsPortalRepositoryMock()
            }
        }
    });

    it('is a Vue instance', async () => {
        const wrapper = mountComponentWithStore(Components, mockStore, { mocks, data, });
        expect(wrapper.isVueInstance).toBeTruthy();
        await expect(
            wrapper.find("#filterComponents").exists()
        ).toBeTruthy();
        expect(
            wrapper.findComponent(EmptyState).exists()
        ).toBeTruthy();
    });

    it('when created repository and store action should be called', async () => {
        const wrapper = mountComponentWithStore(Components, mockStore, { mocks, data, });
        const getComponents = jest.spyOn((wrapper.vm as any).assetsPortalRepository, 'getComponents');
        const setComponentList = jest.spyOn(componentModule.actions, 'setComponentList');
        await flushPromises();
        expect(getComponents).toHaveBeenCalledTimes(1);
        expect(setComponentList).toHaveBeenCalledTimes(1);
    });

    it('when created repository and store action has data returned', async () => {
        componentModule = await new ComponentMockStore().getStore({
            getters: {
                componentList: jest.fn(() => componentList),
            }
        });
        mockStore = {
            modules: {
                property: propertyModule,
                component: componentModule,
            }
        }
        const wrapper = mountComponentWithStore(Components, mockStore, { mocks, data, });

        await flushPromises();
        expect(
            wrapper.findComponent(Table).exists()
        ).toBeTruthy();
    });

    it('display correct filterComponentListElement data', async () => {
        componentModule = await new ComponentMockStore().getStore({
            getters: {
                componentList: jest.fn(() => componentList),
            }
        });
        mockStore = {
            modules: {
                property: propertyModule,
                component: componentModule,
            }
        }
        const wrapper = mountComponentWithStore(Components, mockStore, { mocks, data, });

        wrapper.setData({ filterComponents: "component1" });
        await flushPromises();
        expect(((wrapper.vm as any).filteredComponentElements as any).length).toBe(11)
    })
});