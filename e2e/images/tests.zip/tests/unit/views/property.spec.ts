import Property from "@/views/property.vue";
import { gsap } from "gsap";
import flushPromises from "flush-promises";
import { mountComponentWithStore } from "../../utils";
import PropertyMockStore from "../../mocks/property-mock-store";
import AssetsPortalRepositoryMock from '../../mocks/assets-portal-repository';
import Review from "@/components/property/Review.vue";
import SuccessPrompt from "@/components/property/SuccessPrompt.vue";
import { AssetSearch } from "@/models/asset-search";

describe('property.vue', () => {
    let mockStore: any;    
    let propertyModule: any;
    let mocks: any;
    let data: any;

    beforeEach(async() => {
        propertyModule = await new PropertyMockStore().getStore({
            actions:{
                setProperty:()=>new AssetSearch()
            }
        });
        mocks = {
            $route: {
                params: {
                    id: 1
                }
            }
        };
        data = () => {
            return {
                assetsPortalRepository: AssetsPortalRepositoryMock()
            }
        },
        mockStore = {
            modules: {
                property: propertyModule
            }
        }
    });

    it('is a Vue instance', async () => {
        const wrapper = mountComponentWithStore(Property, mockStore, { mocks, data, });
        expect(wrapper.isVueInstance).toBeTruthy();
        expect(
            wrapper.findComponent(SuccessPrompt).exists()
        ).toBeTruthy();
        expect(
            wrapper.findComponent(Review).exists()
        ).toBeFalsy();
    });

    it('when created repository and store action should be called', async () => {
        const wrapper = mountComponentWithStore(Property, mockStore, { mocks, data, });
        const getAssetsProperty = jest.spyOn((wrapper.vm as any).assetsPortalRepository, 'getAssetsProperty');
        await flushPromises();
        expect(getAssetsProperty).toHaveBeenCalledTimes(1);
    });
});
