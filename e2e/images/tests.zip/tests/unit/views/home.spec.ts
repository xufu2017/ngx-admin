import Home from "@/views/Home.vue";
import flushPromises from "flush-promises";
import { mountComponentWithStore } from "../../utils";
import PropertySearchMockStore from "../../mocks/property-search-mock-store";
import AssetsPortalRepositoryMock from '../../mocks/assets-portal-repository';
describe("Home.vue", () => {
  let mockStore: any;
  const user = {
    firstName: "Joe",
    lastName: "Wade",
    email: "joe.wade@incommunities.co.uk",
  };
  let propertySearchModule: any;
  let identityModule: any;
  let data: any;
  let wrapper: any;
  let mocks: any;
  beforeEach(async () => {
    propertySearchModule = await new PropertySearchMockStore().getStore();
    identityModule = {
      getters: {
        user: () => user
      },
      namespaced: true,
    };
    mockStore = {
      modules: {
        identity: identityModule,
        propertySearch: propertySearchModule,
      },
    };
    data = () => {
      return {
        assetsRepository: AssetsPortalRepositoryMock()
      }
    };
    mocks = {
      $toasted: {
        error: jest.fn().mockImplementation(() => {
          wrapper.vm.$data.errorShown = true
        }),
        success: jest.fn().mockImplementation(() => {
          wrapper.vm.$data.successShown = true
        }),
        show: jest.fn().mockImplementation(() => {
          wrapper.vm.$data.infoShown = true
        })
      }
    }
  });

  afterEach(async () => {
    jest.clearAllMocks();
    await flushPromises();
  });

  it("is a Vue instance", async () => {
    const wrapper = mountComponentWithStore(Home, mockStore);
    expect(wrapper.isVueInstance).toBeTruthy();
  });

  it("has correct elements in markup", async () => {
    const wrapper = mountComponentWithStore(Home, mockStore);
    await flushPromises();

    expect(wrapper.find("#assetPostcode").exists()).toBe(true);
    expect(wrapper.find("#assetAddress").exists()).toBe(true);
    expect(wrapper.find("#assetPropertyCode").exists()).toBe(true);

    const topHeading = wrapper.find(".heading>.content-container>h1");
    expect(topHeading.exists()).toBe(true);
    expect(topHeading.text()).toContain("Joe");
  });

  it("animate can be triggered", async () => {
    const animate = jest.fn();
    const wrapper = mountComponentWithStore(Home, mockStore, {
      methods: {
        animate,
      },
    });
    await flushPromises();
    await expect(animate).toHaveBeenCalledTimes(1);
    expect(wrapper.vm.$data.isSearching).toBeFalsy();
  });

  it("search assets function will be called when search button been clicked ", async () => {
    const searchAssets = jest.fn();
    const wrapper = mountComponentWithStore(Home, mockStore, {
      methods: {
        searchAssets,
      },
    });
    await flushPromises();
    await expect(wrapper.findAll(".button").length).toBe(2);
  });

  it('search asset will be triggered when search button click', async () => {
    wrapper = mountComponentWithStore(Home, mockStore, {
      data, mocks
    });
    const getAssets = jest.spyOn((wrapper.vm as any).assetsRepository, 'getAssets');
    const updateSearchResults = jest.spyOn(propertySearchModule.actions, 'updateSearchResults');

    await flushPromises();

    let searchButton = wrapper.find('.button+.primary');
    expect(searchButton.exists()).toBeTruthy();

    wrapper.setData({ assetPostcode: "bd17" })
    await searchButton.trigger('click');
    await flushPromises();
    expect(getAssets).toHaveBeenCalledTimes(1);
    expect(updateSearchResults).toHaveBeenCalledTimes(1);
  });

  it('should trigger beforeRouteleave event ', async () => {

    const resetPropertySearch = jest.spyOn(propertySearchModule.actions, 'resetPropertySearch');
    mockStore = {
      modules: {
        identity: identityModule,
        propertySearch: propertySearchModule,
      },
    };
    const wrapper = mountComponentWithStore(Home, mockStore);
    await flushPromises();

    const from = '/test1';
    const to = '/test2';
    const next = jest.fn()
    expect(resetPropertySearch).toHaveBeenCalledTimes(0);
  });
});
