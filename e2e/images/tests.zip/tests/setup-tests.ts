import Vue from 'vue'
import Checkbox from "@/components/elements/Checkbox.vue";
import EmptyState from "@/components/elements/EmptyState.vue";
import Icons from "@/components/shared/Icons.vue";
import Input from "@/components/elements/Input.vue";
import Table from "@/components/elements/Table.vue";
import Textarea from "@/components/elements/Textarea.vue";

Vue.component("Checkbox", Checkbox);
Vue.component("EmptyState", EmptyState);
Vue.component("Icon", Icons);
Vue.component("Input", Input);
Vue.component("Textarea", Textarea);
Vue.component("Table", Table);