import { VueConstructor } from "vue/types/vue";
import Vue from "vue";
import Vuex from "vuex";
import {
    shallowMount,
    createLocalVue,
    Wrapper,
    ThisTypedShallowMountOptions,
    mount,
} from "@vue/test-utils";
import { ValidationProvider, ValidationObserver } from "vee-validate";
import validationExtensions from "@/utils/validation-extensions";

export const mountComponentWithStore = <V extends Vue>(
    component: VueConstructor<V>,
    storeOptions: unknown = {},
    mountOptions: ThisTypedShallowMountOptions<V> = {}
): Wrapper<V> => {
    const localVue = createLocalVue();
    localVue.use(Vuex);

    const store = new Vuex.Store({
        ...storeOptions as Record<string, unknown>,
    });

    return shallowMount(component, {
        store,
        localVue,
        ...mountOptions,
    });
};

export const mountValidationWithStore = <V extends Vue>(
    component: VueConstructor<V>,
    storeOptions: unknown = {},
    mountOptions: ThisTypedShallowMountOptions<V> = {}
): Wrapper<V> => {
    const localVue = createLocalVue();
    localVue.use(Vuex);
    localVue.component("ValidationObserver", ValidationObserver);
    localVue.component("ValidationProvider", ValidationProvider);
    validationExtensions.register();
    const store = new Vuex.Store({
        ...storeOptions as Record<string, unknown>,
    });

    return mount(component, {
        store,
        localVue,
        ...mountOptions,
    });
};

export const createContextMock = (props = {}) => ({
    commit: jest.fn(),
    dispatch: jest.fn(),
    ...props,
});

export const mountComponentWithStoreToasted = <V extends Vue>(
    component: VueConstructor<V>,
    storeOptions: unknown = {},
    mountOptions: ThisTypedShallowMountOptions<V> = {}
): Wrapper<V> => {
    let wrapper = {} as any;
    const localVue = createLocalVue();
    localVue.use(Vuex);

    const store = new Vuex.Store({
        ...storeOptions as Record<string, unknown>,
    });

    mountOptions = {
        ...mountOptions,
        mocks: {
            $toasted: {
                error: jest.fn().mockImplementation(() => {
                    wrapper.vm.$data.errorShown = true;
                }),
                success: jest.fn().mockImplementation(() => {
                    wrapper.vm.$data.successShown = true;
                }),
                show: jest.fn().mockImplementation(() => {
                    wrapper.vm.$data.infoShown = true;
                }),
            },
        },
    };
    wrapper = mount(component, {
        store,
        localVue,
        ...mountOptions,
    });

    return wrapper;
};
