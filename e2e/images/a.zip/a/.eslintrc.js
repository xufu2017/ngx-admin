﻿module.exports = {
	"root": true,
	"env": {
		"node": true
	},
	"extends": [
		"plugin:vue/recommended",
		"eslint:recommended",
		"@vue/typescript/recommended"
	],
	"parserOptions": {
		"ecmaVersion": 2020
	},
	"rules": {
		"vue/v-bind-style": ["error", "longform"],
		"vue/v-on-style": ["error", "longform"],
		"vue/v-slot-style": ["error", {
			"atComponent": "longform",
			"default": "longform",
			"named": "longform",
		}],
		"@typescript-eslint/no-this-alias": [
			"error",
			{
				"allowDestructuring": true,
				"allowedNames": ["self"]
			}
		],
		"@typescript-eslint/no-var-requires": 0,
		"@typescript-eslint/no-explicit-any": [
			"off",
			{
				"ignoreRestArgs": true
			}
		],
		"@typescript-eslint/explicit-module-boundary-types": "off"
	},
	overrides: [
		{
			files: [
				'**/__tests__/*.{j,t}s?(x)',
				'**/tests/unit/**/*.spec.{j,t}s?(x)'
			],
			env: {
				jest: true
			}
		}
	]
};