import BaseMockStore from './baseMockStore'
import { propertySearchStore } from "../../src/store/property-search-store"
import { AssetSearchResult } from "../../src/models/asset-search-result"


export default class PropertySearchMockStore extends BaseMockStore {
    _instance = propertySearchStore;
    constructor() {
        super();
    }
    overrideDefault() {
        const moduleStore = super.overrideDefault();
        moduleStore.state = {
            resultsLoading: true,
            propertySearchTableHeadings: [
                "PropertyCode",
                "Address",
                "Town",
                "Postcode",
                "Area",
                "type"
            ],
            propertySearchResults: new Array<AssetSearchResult>()
        };
        moduleStore.getters = {
            resultsLoading: jest.fn().mockReturnValue(true),
            propertySearchTableHeadings: jest.fn().mockReturnValue([
                "PropertyCode",
                "Address",
                "Town",
                "Postcode",
                "Area",
                "type"
            ]),
            propertySearchResults: jest.fn().mockReturnValue(new Array<AssetSearchResult>())
        };
        moduleStore.actions = {
            toggleResultsLoadingState: jest.fn(),
            resetPropertySearch: jest.fn(),
            updateSearchResults: jest.fn()
    };
        return moduleStore;
    }
}
