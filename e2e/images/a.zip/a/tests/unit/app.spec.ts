import App from "@/App.vue";
import { RouterLinkStub } from "@vue/test-utils";
import flushPromises from 'flush-promises';
import { mountComponentWithStore } from "../utils";

describe("app.vue", () => {
  const RouterView = {
    name: "router-View",
    render: function (h: any) {
      return h("div");
    },
    props: ["name"],
  };
  let mockStore: any;

  beforeEach(() => {
    mockStore = {
      modules: {
        navigation: {
          actions: {
            toggleNavigationState: jest.fn(),
          },
          getters: {
            currentNavigationState: jest.fn(),
          },
          namespaced: true,
        },
      },
    };
  });

  it("it is a vue instance", async () => {
    const wrapper = mountComponentWithStore(App, mockStore, {
      stubs: {
        RouterLink: RouterLinkStub,
        RouterView: RouterView,
      },
    });
    expect(wrapper.isVueInstance).toBeTruthy();
    await expect(
      wrapper.findComponent({ name: "Navigation" }).exists()
    ).toBeTruthy();

    await expect(
      wrapper.findComponent({ name: "Header" }).exists()
    ).toBeTruthy();
  });

  it('has main app div ', async () => {
    const wrapper = mountComponentWithStore(App, mockStore, {
      stubs: {
        RouterLink: RouterLinkStub,
        RouterView: RouterView,
      },
    });
    expect(wrapper.find('#app').exists()).toBeTruthy()
  });

  it('keycode can be triggered', async () => {
    const animate = jest.fn();
    const wrapper = mountComponentWithStore(App, mockStore, {
      stubs: {
        RouterLink: RouterLinkStub,
        RouterView: RouterView,
      },
      methods: {
        animate,
      }
    });

    flushPromises();
    expect(wrapper.find('.user-tabbing').exists()).toBeFalsy();
    await expect(animate).toHaveBeenCalledTimes(1);
  });

  it('make correct call to hook the keydown event', async () => {

    const userTabbing = jest.fn();
    const wrapper = mountComponentWithStore(App, mockStore, {
      stubs: {
        RouterLink: RouterLinkStub,
        RouterView: RouterView,
      },
      attachTo: document.body,
      methods: {
        userTabbing
      }
    });

    flushPromises();
    await wrapper.trigger('keydown.up')
    await expect(userTabbing).toBeCalled();
  });

});
