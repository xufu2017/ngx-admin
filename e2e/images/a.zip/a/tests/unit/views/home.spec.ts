import Home from "@/views/Home.vue";
import flushPromises from 'flush-promises';
import { mountComponentWithStore } from "../../utils";

describe('Home.vue', () => {
    let mockStore: any;
    const user = {
        firstName: "Joe",
        lastName: "Wade",
        email: "joe.wade@incommunities.co.uk"
    };
    beforeEach(() => {
        mockStore = {
            modules: {
                identity: {
                    getters: {
                        user: () => user
                    },
                    namespaced: true,
                },
                propertySearch: {
                    actions: {
                        toggleResultsLoadingState: jest.fn(),
                        resetPropertySearch: jest.fn(),
                        updateSearchResults: jest.fn(),
                    },
                    getters: {
                        resultsLoading: jest.fn(),
                        propertySearchTableHeadings: jest.fn(),
                        propertySearchResults: jest.fn(),
                    },
                    namespaced: true,
                }
            },
        };
    });

    it('is a Vue instance', async () => {
        const wrapper = mountComponentWithStore(Home, mockStore);
        expect(wrapper.isVueInstance).toBeTruthy();

    });

    it('animate can be triggered', async () => {
        const animate = jest.fn();
        const wrapper = mountComponentWithStore(Home, mockStore, {
            methods: {
                animate,
            }
        });
        await flushPromises();
        await expect(animate).toHaveBeenCalledTimes(1);
        expect(wrapper.vm.$data.isSearching).toBeFalsy();
    });

    it('search assets function will be called when search button been clicked ', async () => {
        const searchAssets = jest.fn();
        const wrapper = mountComponentWithStore(Home, mockStore, {
            methods: {
                searchAssets,
            }
        });
        await flushPromises();
        await expect(wrapper.findAll('.button').length).toBe(2);
    });
});