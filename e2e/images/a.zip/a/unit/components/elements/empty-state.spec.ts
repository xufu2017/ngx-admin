import { shallowMount } from "@vue/test-utils";
import EmptyState from "@/components/elements/EmptyState.vue";
describe('Checkbox.vue', () => {

    it('It is a vue instance', async () => {
        const component = shallowMount(EmptyState, {
            propsData: {
                value: false,
                title: "test_01",
                "message": "ariaLabel",
                icon: "test"
            },
        });
        expect(component.isVueInstance).toBeTruthy();
        expect(component.classes("empty-state")).toBe(true);
    });
});
