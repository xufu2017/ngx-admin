import { shallowMount } from "@vue/test-utils";
import Checkbox from "@/components/elements/Checkbox.vue";
describe('Checkbox.vue', () => {

    it('It is a vue instance', async () => {
        const component = shallowMount(Checkbox, {
            propsData: {
                value: false,
                id: "test_01",
                "aria-label": "ariaLabel",
                val: "test"
            },
        });
        expect(component.isVueInstance).toBeTruthy();
        await expect(
            component.findComponent({ name: "check" }).exists()
        ).toBeTruthy();
    });

    it("renders value when passed", () => {
        const component = shallowMount(Checkbox, {
            propsData: {
                value: false,
                id: "test_01",
                "aria-label": "ariaLabel",
                val: "test"
            },
        });
        const checkBoxes = component.findAll('#test_01')
        checkBoxes.at(0).setChecked()
        expect(component.emitted('input')).toEqual([[true]]);

    });
});
