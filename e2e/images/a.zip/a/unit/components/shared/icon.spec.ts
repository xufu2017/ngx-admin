import Icon from "@/components/shared/Icons.vue";
import { RouterLinkStub } from "@vue/test-utils";
import { mountComponentWithStore } from "../../../utils";
describe('Icons.vue', () => {
    it('It is a vue instance', async () => {
        const wrapper = mountComponentWithStore(Icon, {}, {
            stubs: {
                RouterLink: RouterLinkStub
            },
            propsData: {
                name: 'logo'
            }
        });
        expect(wrapper.isVueInstance).toBeTruthy();
    });
});