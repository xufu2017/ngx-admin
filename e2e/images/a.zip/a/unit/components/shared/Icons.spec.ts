import Icons from "@/components/shared/icons.vue";
import { mount, MountOptions, Wrapper } from "@vue/test-utils";
describe('Icons.vue', () => {

    type Instance = InstanceType<typeof Icons>;
    let mountFunction: (options?: MountOptions<Instance>) => Wrapper<Instance>;

    beforeEach(() => {
        mountFunction = (options = {}) => {
            return mount(Icons, options);
        };
    });

    it('It is a vue instance', async () => {
        const wrapper = mountFunction({
            propsData: {
                name: 'camera'
            }
        });
        expect(wrapper.isVueInstance).toBeTruthy();
    });

    it('renders value when passed', async () => {
        const wrapper = mountFunction({
            propsData: {
                name: 'camera'
            }
        });
        let svgs = wrapper.findAll("svg");
        expect(svgs.length).toBe(1);
    });

})