import Header from "@/components/shared/Header.vue";
import { RouterLinkStub } from "@vue/test-utils";
import flushPromises from "flush-promises";
import { mountComponentWithStore } from "../../../utils";
describe('Header.vue', () => {
    let mockStore: any;
    const toggleNavigationState = jest.fn();
    beforeAll(() => {
        mockStore = {
            modules: {
                navigation: {
                    actions: {
                        toggleNavigationState,
                    },
                    namespaced: true,
                },
            },
        };
    });

    it('It is a vue instance', async () => {
        const wrapper = mountComponentWithStore(Header, mockStore, {
            stubs: {
                RouterLink: RouterLinkStub
            }
        });
        expect(wrapper.isVueInstance).toBeTruthy();
        await expect(
            wrapper.findComponent({ name: "logo" }).exists()
        ).toBeTruthy();
        await expect(
            wrapper.findComponent({ name: "menu" }).exists()
        ).toBeTruthy();
    });

    it('should call navigation acton method', async () => {
        const wrapper = mountComponentWithStore(Header, mockStore, {
            stubs: {
                RouterLink: RouterLinkStub
            }
        });
        await flushPromises();
        const buttons = wrapper.findAll("button");
        expect(buttons).toBeTruthy();

        buttons.at(0).trigger("click");
        await flushPromises();
        await expect(await toggleNavigationState).toHaveBeenCalledTimes(1);

    });
});