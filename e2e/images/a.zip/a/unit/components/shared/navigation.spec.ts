import Navigation from "@/components/shared/Navigation.vue";
import { RouterLinkStub } from "@vue/test-utils";
import flushPromises from "flush-promises";
import { mountComponentWithStore } from "../../../utils";
import Popper from "vue-popperjs";
describe('Navigation.vue', () => {
    let mockStore: any;
    const user = {
        firstName: "Joe",
        lastName: "Wade",
        email: "joe.wade@incommunities.co.uk"
    };
    const toggleNavigationState = jest.fn();
    beforeAll(() => {
        mockStore = {
            modules: {
                identity: {
                    getters: {
                        user: () => user
                    },
                    namespaced: true,
                },
                navigation: {
                    actions: {
                        toggleNavigationState,
                    },
                    getters: {
                        currentNavigationState: jest.fn(),
                    },
                    namespaced: true,
                },
            },
        };
    });

    it('It is a vue instance', async () => {
        const wrapper = mountComponentWithStore(Navigation, mockStore, {
            stubs: {
                RouterLink: RouterLinkStub
            }
        });
        expect(wrapper.isVueInstance).toBeTruthy();
        await expect(
            wrapper.findComponent({ name: "DarkMode" }).exists()
        ).toBeTruthy();
        await expect(
            wrapper.findComponent(Popper).exists()
        ).toBeTruthy();
    });

    it('should call navigation acton method when click navigation overlay', async () => {
        const wrapper = mountComponentWithStore(Navigation, mockStore, {
            stubs: {
                RouterLink: RouterLinkStub
            }
        });
        await flushPromises();
        const overlay = wrapper.find(".navigation-overlay");
        expect(overlay).toBeTruthy();

        overlay.trigger("click");
        await flushPromises();
        await expect(await toggleNavigationState).toHaveBeenCalledTimes(1);

    });

    it('should call signout method when click singout button', async () => {
        const logOut = jest.fn();
        const wrapper = mountComponentWithStore(Navigation, mockStore, {
            stubs: {
                RouterLink: RouterLinkStub
            },
            methods: {
                logOut
            }
        });
        await flushPromises();
        const buttons = wrapper.findAll("button");
        expect(buttons).toBeTruthy();

        buttons.at(0).trigger("click");
        await flushPromises();
        await expect(await logOut).toHaveBeenCalledTimes(1);

    });
});