import DarkMode from "@/components/shared/DarkMode.vue";
import { RouterLinkStub } from "@vue/test-utils";
import flushPromises from "flush-promises";
import { mountComponentWithStore } from "../../../utils";
describe('DarkMode.vue', () => {
    let mockStore: any;
    beforeAll(() => {
        window.matchMedia = jest.fn().mockImplementation(query => {
            return {
                matches: query === '(min-width: 240px) and (max-width: 767px)' ? false : true,
                media: '',
                onchange: null,
                addListener: jest.fn(),
                removeListener: jest.fn(),
            };
        });
        mockStore = {};
    });

    it('It is a vue instance', async () => {
        const wrapper = mountComponentWithStore(DarkMode, mockStore, {
            stubs: {
                RouterLink: RouterLinkStub
            },
            attachTo: document.body,
        });
        expect(wrapper.isVueInstance).toBeTruthy();
    });

    it('should be update prefer-dark-mode value', async () => {
        const wrapper = mountComponentWithStore(DarkMode, mockStore, {
            stubs: {
                RouterLink: RouterLinkStub
            },
            attachTo: document.body,
        });

        await flushPromises();
        const prefersDarkMode = wrapper.findAll("#prefersDarkMode");
        expect(prefersDarkMode).toBeTruthy();
        await expect(wrapper.vm.$data.prefersDarkMode).toBeTruthy();

        prefersDarkMode.at(0).trigger("click");
        await flushPromises();
        await expect(wrapper.vm.$data.prefersDarkMode).toBeFalsy();
    });
});

