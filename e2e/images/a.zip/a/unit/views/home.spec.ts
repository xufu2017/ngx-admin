import Home from "@/views/Home.vue";
import flushPromises from 'flush-promises';
import { mountComponentWithStore } from "../../utils";
import Input from "@/components/elements/Input.vue";
import PropertySearchMockStore from '../../mocks/propertySearchStore'
describe('Home.vue', () => {
    let mockStore: any;
    const user = {
        firstName: "Joe",
        lastName: "Wade",
        email: "joe.wade@incommunities.co.uk"
    };
    let propertySearchMockStore:any;
    beforeEach(async() => {

        propertySearchMockStore=await new PropertySearchMockStore().getStore({
            actions: {
                toggleResultsLoadingState: jest.fn(),
                updateSearchResults: jest.fn(),
                resetPropertySearch:jest.fn(),
            },
            getters: {
                resultsLoading: jest.fn(),
                propertySearchTableHeadings: jest.fn(),
                propertySearchResults: jest.fn(),
            }
        })
        mockStore = {
            modules: {
                identity: {
                    getters: {
                        user: () => user
                    },
                    namespaced: true,
                },
                propertySearch: propertySearchMockStore
            },
        };
    });

    afterEach(async () => {
        jest.clearAllMocks();
        await flushPromises();
      });
    

    it('is a Vue instance', async () => {
        const wrapper = mountComponentWithStore(Home, mockStore);
        expect(wrapper.isVueInstance).toBeTruthy();

    });

    it('has correct elements in markup', async () => {
        const wrapper = mountComponentWithStore(Home, mockStore);
        await flushPromises();

        expect(wrapper.find("#assetPostcode").exists()).toBe(true);
        expect(wrapper.find("#assetAddress").exists()).toBe(true);
        expect(wrapper.find("#assetPropertyCode").exists()).toBe(true);

        const topHeading = wrapper.find('.heading>.content-container>h1');
        expect(topHeading.exists()).toBe(true);
        expect(topHeading.text()).toContain("Joe")
    });


    it('animate can be triggered', async () => {
        const animate = jest.fn();
        const wrapper = mountComponentWithStore(Home, mockStore, {
            methods: {
                animate,
            }
        });
        await flushPromises();
        await expect(animate).toHaveBeenCalledTimes(1);
        expect(wrapper.vm.$data.isSearching).toBeFalsy();
    });

    it('search assets function will be called when search button been clicked ', async () => {
        const searchAssets = jest.fn();
        const wrapper = mountComponentWithStore(Home, mockStore, {
            methods: {
                searchAssets,
            }
        });
        await flushPromises();
        await expect(wrapper.findAll('.button').length).toBe(2);
    });

    it('should trigger beforeRouteleave event ', async () => {

        const wrapper =await mountComponentWithStore(Home, mockStore);
        
        await flushPromises();
        const pp=mockStore.modules.propertySearch.actions;
        const resetPropertySearch = jest.spyOn(propertySearchMockStore.actions, 'resetPropertySearch');
        const from = '/test1';
        const to = '/test2';
        const next = jest.fn()

       await (wrapper.vm.$options as any).beforeRouteLeave(to, from, next)
        expect(resetPropertySearch).toHaveBeenCalledTimes(1);

    });


});