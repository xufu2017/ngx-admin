import Vue from "vue";
import Vuex, { Module } from "vuex";

Vue.use(Vuex);

export default abstract class BaseMockStore {
    protected abstract _instance: Module<any, any>;

    protected overrideDefault() {
        return {
            state: {},
            getters: {},
            mutations: {},
            actions: {},
        };
    }
    async getStore(store?: any) {
        return {
            namespaced: true,
            getters: {
                ...this._instance.getters,
                ...this.overrideDefault()?.getters,
                ...store?.getters,
            },
            mutations: {
                ...this._instance.mutations,
                ...this.overrideDefault()?.mutations,
                ...store?.mutations,
            },
            actions: {
                ...this._instance.actions,
                ...this.overrideDefault()?.actions,
                ...store?.actions,
            },
            state: {
                ...this._instance.state,
                ...this.overrideDefault()?.state,
                ...store?.state,
            },
        };
    }
}