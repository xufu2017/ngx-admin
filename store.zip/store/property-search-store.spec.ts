import { AssetsSearchQuery } from '@/models/assets-search-query';
import { propertySearchStore } from '@/store/property-search-store';

describe('property-search-store.ts', () => {
    const store = propertySearchStore;
    const state = {
        resultsLoading: true,
        propertySearchTableHeadings: [
            "Property Code",
            "Address",
            "Town",
            "Address Line 2",
            "Address Line 3",
            "Postcode",
            "Area",
            "Type"
        ],
        propertySearchResults: new AssetsSearchQuery()
    }
    let mutations: any;
    let getters: any;
    let actions: any;

    beforeEach(() => {
        state.propertySearchResults = new AssetsSearchQuery()
        if (store.actions) {
            actions = store.actions
        }
        if (store.mutations) {
            mutations = store.mutations;
        }
        if (store.getters)
            getters = store.getters;
    });

    describe('mutations', () => {

        it('can toggleResultsLoadingState', async () => {
            let oldResultLoading = state.resultsLoading;
            mutations["toggleResultsLoadingState"](state);
            expect(state.resultsLoading).toBe(!oldResultLoading);
        });

        it('can resetPropertySearch', async () => {
            mutations["resetPropertySearch"](state);
            expect(state.resultsLoading).toBeTruthy();
        });

        it('can update search results ', async () => {
            let payload = new AssetsSearchQuery();
            payload.addressLine1 = "update address 1";
            mutations["updateSearchResults"](state, payload);
            expect(state.propertySearchResults.addressLine1).toBe("update address 1");
        });

    });

    describe('actions', () => {
        it('can call toggleResultsLoadingState ', async () => {
            const commit = jest.fn();
            actions["toggleResultsLoadingState"]({ commit });
            expect(commit).toHaveBeenCalledTimes(1);
        });

        it('can call resetPropertySearch ', async () => {
            const commit = jest.fn();
            actions["resetPropertySearch"]({ commit });
            expect(commit).toHaveBeenCalledTimes(1);
        });

        it('can call updateSearchResults ', async () => {
            const commit = jest.fn();
            actions["updateSearchResults"]({ commit }, state.propertySearchResults);
            expect(commit).toHaveBeenCalledTimes(1);
            expect(commit).toHaveBeenCalledWith("updateSearchResults", state.propertySearchResults);
        });
    });


    describe('getters', () => {
        it('can get resultsLoading', async () => {
            const resultsLoading = state.resultsLoading;
            const result = getters["resultsLoading"](state);
            expect(result).toBe(resultsLoading);
        });

        it('can get propertySearchTableHeadings', async () => {
            const propertySearchTableHeadings = state.propertySearchTableHeadings;
            const result = getters["propertySearchTableHeadings"](state);
            expect(result).toBe(propertySearchTableHeadings);
        });

        it('can get propertySearchResults', async () => {
            const propertySearchResults = state.propertySearchResults;
            const result = getters["propertySearchResults"](state);
            expect(result).toBe(propertySearchResults);
        });

    });
});