import { Component } from '@/models/component';
import { componentStore } from '@/store/component-store';

describe('component-store.ts', () => {
    const store = componentStore;
    const state = {
        resultsLoading: true,
        componentTableHeadings: [
            "Name",
            "ComponentType"
        ],
        componentList: new Array<Component>()
    }
    let mutations: any;
    let getters: any;
    let actions: any;

    beforeEach(() => {
        state.componentList = new Array<Component>()
        if (store.actions) {
            actions = store.actions
        }
        if (store.mutations) {
            mutations = store.mutations;
        }
        if (store.getters)
            getters = store.getters;
    });

    describe('mutations', () => {

        it('can setComponentList', async () => {
            let oldResultLoading = state.resultsLoading;
            let componentList = Array(40)
            .fill(null)
            .map((v, i) => ({
                assetId: 1,
                componentId: i,
                name: 'component' + i
            }));
            mutations["setComponentList"](state,componentList);
            expect(state.resultsLoading).toBe(false);

            expect(state["componentList"].length).toBe(40);
        });
    });

    describe('actions', () => {
        it('can call setComponentList ', async () => {
            const commit = jest.fn();
            let componentList = Array(10)
            .fill(null)
            .map((v, i) => ({
                assetId: 1,
                componentId: i,
                name: 'component' + i
            }));
            actions["setComponentList"]({ commit },componentList);
            expect(commit).toHaveBeenCalledTimes(1);
            expect(commit).toHaveBeenCalledWith("setComponentList", componentList);
        });
    });


    describe('getters', () => {
        it('can get resultsLoading', async () => {
            const resultsLoading = state.resultsLoading;
            const result = getters["resultsLoading"](state);
            expect(result).toBe(resultsLoading);
        });

        it('can get componentTableHeadings', async () => {
            const componentTableHeadings = state.componentTableHeadings;
            const result = getters["componentTableHeadings"](state);
            expect(result).toBe(componentTableHeadings);
        });

        it('can get componentList', async () => {
            const componentList = state.componentList;
            const result = getters["componentList"](state);
            expect(result).toBe(componentList);
        });

    });
});