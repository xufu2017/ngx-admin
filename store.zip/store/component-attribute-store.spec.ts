import { ComponentAttribute } from '@/models/component-attribute';
import { ComponentSearch } from '@/models/component-search';
import { componentAttributeStore } from '@/store/component-attribute-store';

describe('component-store.ts', () => {
    const store = componentAttributeStore;
    const state = {
        componentsLoading: true,
        componentUpdates: [],
        componentUpdatesTableHeadings: [
            "Name",
            "Value"
        ],
        componentAttributes: new Array<Array<ComponentAttribute>>(),
        componentAttributeResults: new Array<ComponentAttribute>()
    }
    let componentAttributelist: Array<ComponentAttribute> = new Array<ComponentAttribute>();

    let mutations: any;
    let getters: any;
    let actions: any;

    beforeEach(() => {
        state.componentAttributes = new Array<Array<ComponentAttribute>>();
        state.componentAttributeResults = new Array<ComponentAttribute>();
        componentAttributelist = Array(40)
            .fill(null).map((v, i) => {
                let ca = new ComponentAttribute();
                ca.componentElementId = 1;
                return ca;
            });

        if (store.actions) {
            actions = store.actions
        }
        if (store.mutations) {
            mutations = store.mutations;
        }
        if (store.getters)
            getters = store.getters;
    });

    describe('mutations', () => {

        it('can componentSearchResults', async () => {
            let oldResultLoading = state.componentsLoading;
            let payload = new ComponentSearch();
            payload.results = componentAttributelist;
            mutations["componentSearchResults"](state, payload);
            expect(state.componentsLoading).toBe(false);

            expect(state["componentAttributeResults"].length).toBe(40);
        });

        it('can componentEditSearchResults', async () => {
            let oldResultLoading = state.componentsLoading;
            state.componentAttributes = [componentAttributelist];
            let comp = { componentElementId: 1 };

            mutations["componentEditSearchResults"](state, comp);
            expect(state.componentsLoading).toBe(false);

            expect(state["componentAttributeResults"].length).toBe(40);
        });

    });

    describe('actions', () => {
        it('can call componentSearchResults ', async () => {
            const commit = jest.fn();
            let componentSearch = new ComponentSearch();
            componentSearch.results = componentAttributelist;
            actions["componentSearchResults"]({ commit }, componentSearch);
            expect(commit).toHaveBeenCalledTimes(1);
            expect(commit).toHaveBeenCalledWith("componentSearchResults", componentSearch);
        });

        it('can call componentEditSearchResults ', async () => {
            const commit = jest.fn();
            let comp = { componentElementId: 1 };
            actions["componentEditSearchResults"]({ commit }, comp);
            expect(commit).toHaveBeenCalledTimes(1);
            expect(commit).toHaveBeenCalledWith("componentEditSearchResults", comp);
        });

    });


    describe('getters', () => {
        it('can get componentsLoading', async () => {
            const resultsLoading = state.componentsLoading;
            const result = getters["componentsLoading"](state);
            expect(result).toBe(resultsLoading);
        });

        it('can get componentUpdatesTableHeadings', async () => {
            const componentUpdatesTableHeadings = state.componentUpdatesTableHeadings;
            const result = getters["componentUpdatesTableHeadings"](state);
            expect(result).toBe(componentUpdatesTableHeadings);
        });

        it('can get componentAttributeResults', async () => {
            const componentAttributeResults = state.componentAttributeResults;
            const result = getters["componentAttributeResults"](state);
            expect(result).toBe(componentAttributeResults);
        });

        it('can get componentUpdates', async () => {
            const componentUpdates = state.componentUpdates;
            const result = getters["componentUpdates"](state);
            expect(result).toBe(componentUpdates);
        });

        it('can get componentAttributes', async () => {
            const componentAttributes = state.componentAttributes;
            const result = getters["componentAttributes"](state);
            expect(result).toBe(componentAttributes);
        });

    });
});