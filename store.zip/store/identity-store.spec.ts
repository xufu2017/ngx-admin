import {identityStore} from "@/store/identity-store";
import {User} from "@/models/user";

describe('identity-store.ts', () => {
    const user=new User('Von',"Miller","joe.wang@incommunities.co.uk");
    const store = identityStore;
    const state = {
        user: new User,
        signedIn: false,
    };

    beforeEach(async () => {
        state.user = new User;
        state.signedIn = false;
        state.signedIn = false as boolean;
    });

    describe('mutations', () => {
        it('can updateUser', async () => {           
            if(store.mutations) {
                store.mutations["updateUser"](state, user);
            }
            
            expect(state.user).toBe(user);
        });
        
        it('can updateSignedIn', async () => {
            if(store.mutations) {
                store.mutations["updateSignedIn"](state, true);
            }

            expect(state.signedIn).toBe(true);
        });
    });

    describe('actions', () => {
        
        it('calls updateUser mutation when updateUser action is called', async () => {
            const commit = jest.fn();

            if(store.actions) {
                const action = store.actions.updateUser as Function
                action({commit}, user);
            }

            expect(commit).toHaveBeenCalledTimes(1);
            expect(commit).toHaveBeenCalledWith("updateUser", user);
        });

        it('calls updateSignedIn mutation when updateSignedIn action is called', async () => {
            const commit = jest.fn();

            if(store.actions) {
                const action = store.actions.updateSignedIn as Function
                action({commit}, true);
            }

            expect(commit).toHaveBeenCalledTimes(1);
            expect(commit).toHaveBeenCalledWith("updateSignedIn", true);
        });
    });


    describe('getters', () => {
        it('returns first character of username when userInitial called', async () => {
            state.user = user;
            
            if(store.getters){
                // @ts-ignore
                expect(store.getters["userInitial"](state)).toStrictEqual(user.firstName[0].toLowerCase());
            }
        });
        
        it('returns user when user called', async () => {
            state.user = user;

            if(store.getters){
                // @ts-ignore
                expect(store.getters["user"](state)).toStrictEqual(user);
            }
        });

        it('returns signedIn when signedIn called', async () => {
            state.signedIn = true;

            if(store.getters){
                // @ts-ignore
                expect(store.getters["signedIn"](state)).toStrictEqual(true);
            }
        });

        it('returns fullName when fullName called', async () => {
            state.user = user;
            
            if(store.getters){
                // @ts-ignore
                expect(store.getters["fullName"](state)).toStrictEqual(`${user.firstName} ${user.lastName}`);
            }
        });
    });
});
