import Vue from 'vue';
import Toasted from 'vue-toasted';
import Vuex from 'vuex';
import App from './App.vue';
import './registerServiceWorker';
import router from './router';
import { dampReportStore } from './store/damp-report-store';

Vue.use(Toasted);
Vue.use(Vuex);

Vue.config.productionTip = false;

const store = new Vuex.Store({
    modules: {
        dampReport: dampReportStore
    }
});

new Vue({
    router,
    store,
    render: h => h(App)
}).$mount('#app');
