﻿export enum Controller {
    Assets = "Assets"
}