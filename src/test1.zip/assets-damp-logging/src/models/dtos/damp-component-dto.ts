﻿import { JsonObject, JsonProperty } from "json2typescript";
import { OptionDto } from "@/models/dtos/option-dto";

@JsonObject("damp")
export class DampComponentDto {
    @JsonProperty("Id", Number)
    id: number = 0;
    @JsonProperty("Name", String)
    name: string = "";
    @JsonProperty("Options", [OptionDto], true)
    options: OptionDto[] = new Array<OptionDto>();
    @JsonProperty("ControlTypeId", Number)
    controlTypeId: number = 0;
}