﻿import {JsonObject, JsonProperty} from "json2typescript";

@JsonObject("User")
export class User {
    @JsonProperty("firstname", String)
    firstName: string = "";
    @JsonProperty("lastname", String)
    lastName: string = "";
    @JsonProperty("email", String)
    email: string = "";
    @JsonProperty("role", [String], true)
    roles: string[] = [];
    @JsonProperty("sub", String)
    userId: string = "";
}