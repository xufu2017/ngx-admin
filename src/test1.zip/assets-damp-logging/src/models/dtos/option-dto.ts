﻿import { JsonObject, JsonProperty } from "json2typescript";

@JsonObject("option")
export class OptionDto {
    @JsonProperty("Id", Number)
    id: number = 0;
    @JsonProperty("Value", String)
    value: string = "";
}
