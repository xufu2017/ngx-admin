<template>
    <div>
        <div class="input-container">
            <label for="propertyAddress">Property Address</label>
            <input type="text" id="propertyAddress" name="propertyAddress" placeholder="e.g Victoria Street Shipley BD17 7BN" />
        </div>
    </div>
</template>

<script lang="ts">
    import Vue from 'vue';
    import Component from 'vue-class-component';
    import { namespace } from "vuex-class";

    const dampReportModule = namespace('dampReport');

    @Component
    export default class PropertySearch extends Vue {
        @dampReportModule.Action updateTitle: any;

        created() {
            this.updateTitle("Report Details");   
        }
    };
</script>