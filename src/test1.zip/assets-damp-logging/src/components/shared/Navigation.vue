<template>
    <nav class="system-navigation" v-bind:class="{visible: visibleNavigation, show: showNavigation,}">
        <header>
            <router-link to="/">
                <svg>
                    <use href="#logo" />
                </svg>
                <p>Damp Reporting</p>
            </router-link>
        </header>

        <div class="content">
            <ul>
                <li v-for="(route, i) in routes" v-bind:key="i" v-on:click="toggleNavigation">
                    <router-link v-bind:to="route.url">{{route.name}}</router-link>
                </li>
            </ul>
        </div>
    </nav>
</template>

<script lang="ts">
    import Vue from 'vue';
    import Component from 'vue-class-component';
    import { namespace } from "vuex-class";

    const dampReportModule = namespace('dampReport');

    @Component
    export default class Navigation extends Vue {
        @dampReportModule.Action toggleNavigation: any;

        @dampReportModule.Getter visibleNavigation: any;
        @dampReportModule.Getter showNavigation: any;

        routes = [
            {
                url: "/",
                name: "Create a new report"
            },
            {
                url: "/about",
                name: "About us"
            }
        ]
    }
</script>