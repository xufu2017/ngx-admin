import Vue from 'vue';
import VueRouter from 'vue-router';

const Home = () => import(/* webpackChunkName: "home" */ '../views/Home.vue');
const About = () => import(/* webpackChunkName: "about" */ '../views/About.vue');
const Damp = () => import(/* webpackChunkName: "damp" */ '../views/Damp.vue');
const Camera = () => import(/* webpackChunkName: "camera" */ '../views/Camera.vue');
const ImageAttachments = () => import(/* webpackChunkName: "imageAttachments" */ '../views/ImageAttachments.vue');

Vue.use(VueRouter);

const routes = [
    {
        path: '/',
        name: 'Home',
        component: Home
    },
    {
        path: '/about',
        name: 'About',
        component: About
    },
    {
        path: '/damp',
        name: 'Damp',
        component: Damp
    },
    {
        path: '/camera',
        name: 'Camera',
        component: Camera
    },
    {
        path: '/imageAttachments',
        name: 'ImageAttachments',
        component: ImageAttachments
    }
];

const router = new VueRouter({
    mode: 'history',
    base: process.env.BASE_URL,
    routes
});

export default router
