<template>
    <div id="app">
        <Header />

        <Navigation />

        <div class="overlay"
             v-on:click="toggleNavigation"
             v-bind:class="{show: showNavigation, visible: visibleNavigation}"></div>

        <router-view />
    </div>
</template>

<script lang="ts">
    import Vue from 'vue';
    import Component from 'vue-class-component';
    import { Watch } from "vue-property-decorator";
    import { namespace } from "vuex-class";

    import AssetsRepository from './repositories/assets-repository';
    import Header from '@/components/shared/Header.vue';
    import Navigation from '@/components/shared/Navigation.vue';

    const dampReportModule = namespace('dampReport');

    @Component({
        components: {
            Header,
            Navigation
        }
    })
    export default class App extends Vue {
        assetsRepository: AssetsRepository = new AssetsRepository(); 
        
        @dampReportModule.Action toggleNavigation: any;
        @dampReportModule.Action updateDampComponent: any;

        @dampReportModule.Getter visibleNavigation: any;
        @dampReportModule.Getter showNavigation: any;

        onlineStatus = navigator.onLine;
        showBackOnline = false;

        updateOnlineStatus(e: any) {
            const { type } = e;
            this.onlineStatus = type === "online";
        }

        async created() {
            await this.updateDampComponent(
                await this.assetsRepository.getDampComponent()
            );
        }

        mounted() {
            window.addEventListener("online", this.updateOnlineStatus);
            window.addEventListener("offline", this.updateOnlineStatus);
        }
        beforeDestroy() {
            window.removeEventListener("online", this.updateOnlineStatus);
            window.removeEventListener("offline", this.updateOnlineStatus);
        }

        @Watch('onlineStatus')
        onStatusChange(value: boolean) {
            if (value) {
                this.showBackOnline = true;
                setTimeout(() => {
                    this.showBackOnline = false;
                    this.$toasted.success(
                        '<svg><use href="#connection"></use></svg><p>Device successfully connected to the internet.</p>',
                        {
                            position: "bottom-right",
                            duration: 5000,
                        }
                    );
                }, 1000);
            } else {
                setTimeout(() => {
                    this.$toasted.error(
                        '<svg><use href="#no-connection"></use></svg><p>You have lost connection to the internet, some functionality will be limited.</p>',
                        {
                            position: "bottom-right",
                            duration: 5000,
                        }
                    );
                }, 1000);
            }
        }
    }
</script>

<style lang="scss">
    * {
        font-family: sans-serif;
    }

    .toasted-container {
        svg

    {
        width: 30px;
        height: 30px;
        display: inline-block;
        margin-right: 0.75rem;
        fill: #fff;
    }

    p {
        flex: 1;
    }
    }
</style>