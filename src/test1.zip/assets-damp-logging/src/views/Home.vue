<template>
    <main class="home">
        <div class="empty-state">
            <figure>
                <svg>
                    <use href="#folder" />
                </svg>
            </figure>

            <h3>Get started creating a new report by clicking the button below</h3>

            <router-link to="/Damp" class="button white">Get started</router-link>
        </div>
    </main>
</template>

<script lang="ts">
    import Vue from 'vue';
    import Component from 'vue-class-component';
    import { namespace } from "vuex-class";

    const dampReportModule = namespace('dampReport');

    @Component
    export default class Home extends Vue {
        @dampReportModule.Action updateTitle: any;

        created() {
            this.updateTitle("Report Details");
        }
    }
</script>
