<template>
    <div class="wrapper">
        <video class="video" :class="facingMode === 'user' ? 'front' : ''" ref="video" />
        <canvas style="display:none" ref="canva" />

        <button v-if="isCameraOn == true"
                class="button is-rounded is-outlined switch-button"
                @click="turnCameraOff">
            Stop Camera
        </button>

        <button v-if="isCameraOn == false"
                class="button is-rounded is-outlined switch-button"
                @click="StartRecording">
            Start Camera
        </button>

        <div class="photo-button-container">
            <button v-if="isCameraOn == true" class="button photo-button" @click="takePhoto">
            </button>
        </div>
        <image-attachments class="gallery" :photos="photos" />
    </div>
</template>

<script lang="ts">
    import Vue from 'vue';
    import Component from 'vue-class-component';
    import { namespace } from "vuex-class";
    import ImageAttachments from "../views/ImageAttachments.vue";

    const dampReportModule = namespace('dampReport');

    @Component({
        components: { ImageAttachments }
    })
    export default class Camera extends Vue {
        @dampReportModule.Getter title: any;

        private videoDevices: MediaDeviceInfo[] = [];
        private facingMode: string = "environment";
        private photos: [{ id: number, src: string }] = [{ id: 0, src: "" }];
        private counter: number = 0;
        private isCameraOn: boolean = true;


        async startCamera(facingMode: string) {
            this.facingMode = facingMode;
            let video = document.querySelector('video');
            const mediaStream = await navigator.mediaDevices.getUserMedia({
                video: { facingMode: facingMode }
            });

            video!.srcObject = mediaStream;
            this.isCameraOn = true;
            return await video!.play();
        }

        async takePhoto() {
            let video = document.querySelector('video');
            let canva = document.querySelector('canvas');
            let width = video!.videoWidth;
            let height = video!.videoHeight;
            canva!.width = width;
            canva!.height = height;
            let ctx = canva!.getContext("2d");
            ctx!.save();

            if (this.facingMode === "user") {
                ctx!.scale(-1, 1);
                ctx!.drawImage(video!, width * -1, 0, width, height);
            } else {
                ctx!.drawImage(video!, 0, 0);
            }

            ctx!.restore();

            this.photos.push({
                id: this.counter++,
                src: canva!.toDataURL("image/png")
            });
        }

        async turnCameraOff() {
            const mediaStream = await navigator.mediaDevices.getUserMedia({
                video: { facingMode: this.facingMode }
            });
            const tracks = mediaStream.getVideoTracks();
            tracks.forEach(track => {
                track.stop();
            });
            this.isCameraOn = false;
        }

        async mounted() {
            const devices = await navigator.mediaDevices.enumerateDevices();
            this.videoDevices = devices.filter(d => d.kind === "videoinput");
            await this.startCamera(this.videoDevices.length === 1 ? "user" : "environment");
        }
    }
</script>

<style scoped>
    .video.front {
        -webkit-transform: scaleX(-1);
        transform: scaleX(-1);
    }

    .wrapper {
        background-color: black;
        display: grid;
        width: 100vw;
        height: 100vh;
        grid-template-columns: [left] 90vw [bs] 5vw [es] 5vw [right];
        grid-template-rows: [top] 5vh [bs] 5vh [es] 60vh [middle] 10vh [bottom] 20vh [end];
        justify-items: center;
        overflow: hidden;
    }

    .video {
        height: 100%;
        grid-column: left/right;
        grid-row: top / bottom;
        user-select: none;
        max-width: unset;
    }

    .photo-button-container {
        grid-column: left / right;
        grid-row: middle / bottom;
        z-index: 5;
        width: 100vw;
        height: 20vh;
        display: flex;
        justify-content: center;
    }

    .photo-button {
        width: 10vh;
        height: 10vh;
        border-radius: 100%;
    }

    .photo-button {
        font-size: 4vh;
        color: black;
    }

    .gallery {
        grid-column: left / right;
        grid-row: bottom / end;
    }
</style>