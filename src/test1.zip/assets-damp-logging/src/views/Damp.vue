<template>
    <div>
        <div v-for="attribute in dampComponentIndex" v-bind:key="attribute.id">
            <label> {{ attribute.name }} </label>
            <div v-if="attribute.controlTypeId === 4">
                <select v-if="attribute.options.length > 0">
                    <option selected disabled>Please Select</option>
                    <option v-for="option in attribute.options" v-bind:key="option.id">
                        {{ option.value }}
                    </option>
                </select>
            </div>
            <div v-if="attribute.controlTypeId === 1">
                <textarea></textarea>
            </div>
        </div>
        <div v-if="pageNumber == 1">
            <button v-on:click="clickNext" class="button white">Next</button>
        </div>
        <div v-if="pageNumber != 1 && pageNumber * 10 - 1 < dampComponent.length">
            <button v-on:click="clickPrevious" class="button white">Previous</button>
            <div v-if="pageNumber != 9">
                <button v-on:click="clickNext" class="button white">Next</button>
            </div>

            <div v-if="pageNumber == 9">
                <router-link to="/ImageAttachments" class="button white">Next</router-link>
            </div>
        </div>
    </div>
</template>

<script lang="ts">
    import Vue from 'vue';
    import Component from 'vue-class-component';
    import { namespace } from "vuex-class";
    import { DampComponentDto } from '../models/dtos/damp-component-dto';

    const dampReportModule = namespace('dampReport');

    @Component
    export default class Damp extends Vue {
        @dampReportModule.Action updatePage: any;

        @dampReportModule.Getter title: any;
        @dampReportModule.Getter dampComponent!:  DampComponentDto[];
        @dampReportModule.Getter dampComponentIndex!:  DampComponentDto[];
        @dampReportModule.Getter pageNumber!:  number;
        @dampReportModule.Getter itemsPerPage!:  number;

        async clickNext() {
            let currentPageNumber = this.pageNumber
            currentPageNumber++
            await this.updatePage(currentPageNumber);
        }

        async clickPrevious() {
            let currentPageNumber = this.pageNumber
            currentPageNumber--
            await this.updatePage(currentPageNumber)
        }
    }
</script>