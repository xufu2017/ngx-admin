<template>
    <main class="about">
        <h1>{{ title }}</h1>
    </main>
</template>

<script lang="ts">
    import Vue from 'vue';
    import Component from 'vue-class-component';
    import { namespace } from "vuex-class";

    const dampReportModule = namespace('dampReport');

    @Component
    export default class About extends Vue {
        @dampReportModule.Action updateTitle: any;

        @dampReportModule.Getter title: any;

        async created() {
            await this.updateTitle("About Us");
        }
    }
</script>