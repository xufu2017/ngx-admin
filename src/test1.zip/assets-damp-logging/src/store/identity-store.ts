﻿import { Module } from "vuex";
import { User } from "@/models/dtos/user";

export const identityStore: Module<any, any> = {
    namespaced: true,
    state: {
        user: new User,
        signedIn: false
    },
    mutations: {
        updateUser (state: any, user: User){
            state.user = user;
        },
        updateSignedIn (state: any, signedIn: boolean){
            state.signedIn = signedIn;
        }
    },
    actions: {
        async updateUser (context: any, user: User){
            await context.commit("updateUser", user);
        },
        async updateSignedIn (context: any, signedIn: boolean){
            await context.commit("updateSignedIn", signedIn);
        }
    },
    getters: {
        userInitial(state) {
            return state.user.firstName.toLowerCase().charAt(0);
        },
        user(state) {
            return state.user;
        },
        signedIn(state) {
            return state.signedIn;
        },
        fullName(state) {
            return `${state.user.firstName} ${state.user.lastName}`;
        }
    }
}