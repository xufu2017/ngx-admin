import { Module } from 'vuex';
import { DampComponentDto } from '../models/dtos/damp-component-dto';

export const dampReportStore: Module<any, any> = {
    namespaced: true,
    state: {
        title: "Damp Reporting",
        visibleNavigation: false,
        showNavigation: false,
        dampComponent: [],
        dampComponentIndex: [],
        pageNumber: 1,
        itemsPerPage: 10
    },
    mutations: {
        toggleNavigation: (state) => {
            state.visibleNavigation = !state.visibleNavigation;
            setTimeout(() => {
                state.showNavigation = !state.showNavigation;
            }, 200);
        },
        updateTitle: (state: any, title: string) => {
            state.title = title;
        },
        updateDampComponent: (state: any, dampComponent: DampComponentDto[]) => {
            state.dampComponent = dampComponent;
        },
        updateDampComponentIndex: (state: any) => {
            state.dampComponentIndex = state.dampComponent.slice((state.pageNumber - 1) * state.itemsPerPage
                , state.pageNumber * (state.itemsPerPage - 1));
        },
        updatePage(state: any, pageNumber: number) {
            state.pageNumber = pageNumber;
        }
    },
    actions: {
        async toggleNavigation(context: any) {
            await context.commit("toggleNavigation");
        },
        async updateTitle(context: any, title: string) {
            await context.commit("updateTitle", title);
        },
        async updateDampComponent(context: any, dampComponent: DampComponentDto[]) {
            await context.commit("updateDampComponent", dampComponent);
            await context.commit("updateDampComponentIndex");
        },
        async updatePage(context: any, pageNumber: number) {
            await context.commit("updatePage", pageNumber);
            await context.commit("updateDampComponentIndex");
        }
    },
    getters: {
        title(state) {
            return state.title;
        },
        visibleNavigation(state) {
            return state.visibleNavigation;
        },
        showNavigation(state) {
            return state.showNavigation;
        },
        dampComponent(state) {
            return state.dampComponent;
        },
        dampComponentIndex(state) {
            return state.dampComponentIndex;
        },
        pageNumber(state) {
            return state.pageNumber;
        },
        itemsPerPage(state) {
            return state.itemsPerPage;
        }
    } 
}