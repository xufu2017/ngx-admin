//import Oidc from 'oidc-client';

//const mgr = new Oidc.UserManager({
//  authority: process.env.VUE_APP_IDENTITY_URL,
//  client_id: process.env.VUE_APP_CLIENT_ID,
//  redirect_uri: process.env.VUE_APP_REDIRECT_URI,
//  scope: 'openid profile PortalAPI.Forms',
//  response_type: 'id_token token',
//  silent_redirect_uri: process.env.VUE_APP_SILENT_REDIRECT_URI,
//  userStore: new Oidc.WebStorageStateStore({store: localStorage}),
//  automaticSilentRenew: true,
//  filterProtocolClaims: true,
//  loadUserInfo: true,
//  monitorSession: false
//});

//Oidc.Log.logger = console;
//Oidc.Log.level = process.env.NODE_ENV === "development" ? Oidc.Log.INFO : Oidc.Log.WARN

//mgr.events.addAccessTokenExpired(async function () {
//  try {
//    await mgr.signinSilent();
//  }
//  catch(error) {
//    console.log(error);
//    if(error.message.includes('login_required')) await mgr.signinRedirect();
//  }
//});

//export default class Identity {
//  signIn () {
//    mgr.signinRedirect().catch(function (err) {
//      console.log(err)
//    })
//  }

//  async silentSignIn () {
//    await mgr.signinSilent();
//    await mgr.signinSilentCallback();
    
//    return ((await mgr.getUser())?.access_token);
//  }
  
//  async getUser () {
//    return await mgr.getUser().catch(function (err) {
//      console.log(err)
//    })
//  }

//  getProfile () {
//    const self = this
//    return new Promise((resolve, reject) => {
//      mgr.getUser().then(function (user) {
//        if (user == null) {
//          self.signIn()
//          return resolve(null)
//        } else{
//          return resolve(user)
//        }
//      }).catch(function (err) {
//        console.log(err)
//        return reject(err)
//      });
//    })
//  }
  
//  signOut () {
//    mgr.signoutRedirect().then(function (resp) {
//      console.log('signed out', resp);
//    }).catch(function (err) {
//      console.log(err)
//    })
//  }

//  getSignedIn () {
//    const self = this
//    return new Promise<boolean>((resolve, reject) => {
//      mgr.getUser().then(function (user) {
//        if (user == null) {
//          self.signIn()
//          return resolve(false)
//        } else{
//          sessionStorage.User = JSON.stringify(user.profile);
//          return resolve(true)
//        }
//      }).catch(function (err) {
//        console.log(err)
//        return reject(err)
//      });
//    })
//  }

//  getRole () {
//    const self = this
//    return new Promise<string[]>((resolve, reject) => {
//      mgr.getUser().then(function (user) {
//        if (user == null) {
//          self.signIn()
//          return resolve()
//        } else{          
//          return resolve(user.profile.role as Array<string>)
//        }
//      }).catch(function (err) {
//        console.log(err)
//        return reject(err)
//      });
//    })
//  }
  
//  getAccessToken(){
//    const self = this
//    return new Promise((resolve, reject) => {
//      mgr.getUser().then(function (user) {
//        if (user == null) {
//          self.signIn()
//          return resolve(null)
//        } else{
//          return resolve(user.access_token)
//        }
//      }).catch(function (err) {
//        console.log(err)
//        return reject(err)
//      });
//    })
//  }
//}