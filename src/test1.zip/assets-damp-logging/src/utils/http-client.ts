﻿import Vue from "vue";
import Axios from 'axios'
import { Controller } from "../models/enums/controller"
import { identityStore } from '@/store/identity-store'
//import Mgr from './identity'

const defaultError = new Error("An unknown error occured while trying to send the axios request.");
//const mgr = new Mgr();

export default class HttpClient {

    constructor() {
        //const user = identityStore.state.user;
        //Axios.defaults.headers.common["UserName"] = user.fullName;
        //Axios.defaults.headers.common["UserId"] = user.userId;
        Axios.defaults.baseURL = process.env.VUE_APP_ASSETS_URL;

        Axios.interceptors.response.use(response => response, async (error) => {
            if (error && error.config && error.response && error.response.status === 401 && !error.config.isRetry) {

                error.config.isRetry = true;
                console.log('Axios call failed due to an authentication error! Attempting to refresh access token....');

                //error.config.headers.Authorization = `Bearer ${await mgr.silentSignIn()}`;
                return Axios.request(error.config);
            } else if (error && error.config && error.response && error.response.status === 404 && !error.config.isRetry) {

                error.config.isRetry = true;

                if (Vue.toasted) {
                    Vue.toasted.info("No results were found!", {
                        position: "bottom-right",
                        duration: 2000
                    });
                }
            } else if (error && error.config && !error.config.isRetry) {

                error.config.isRetry = true;

                if (Vue.toasted) {
                    Vue.toasted.error("Oops, something went wrong!", {
                        position: "bottom-right",
                        duration: 2000
                    });
                }
            }

            if (!error) await Promise.reject(defaultError);

            return Promise.reject(error);
        });
    }

    //protected async ensureTrueToken() {
    //    Axios.defaults.headers.Authorization = `Bearer ${await mgr.getAccessToken()}`;
    //}

    protected async getById<T>(id: number, controller: Controller): Promise<T> {
        //await this.ensureTrueToken()

        return new Promise<T>((resolve, reject) => {
            Axios.get<T>(`/${controller}/${id}`)
                .then(response => resolve(response.data))
                .catch(error => {
                    if (!error) reject(defaultError);
                    reject(new Error(error));
                });
        });
    }

    protected async getAll<T>(controller: Controller): Promise<T> {
        //await this.ensureTrueToken()

        return new Promise<T>((resolve, reject) => {
            Axios.get<T>(`/${controller}/DataSchema`)
                .then(response => {
                    resolve(response.data);
                })
                .catch(error => {
                    console.log(error.message);
                    if (!error) reject(defaultError);
                    reject(new Error(error));
                });
        });
    }

    protected async search<T>(pagingInfo: object, controller: Controller, url: string = "search"): Promise<T> {
        //await this.ensureTrueToken()

        return new Promise<T>(resolve => {
            Axios.post(`/${controller}/${url}`, pagingInfo)
                .then(response => resolve(response.data))
                .catch(error => {
                    error.isError = true;
                    return resolve(error);
                });
        });
    }

    protected async post<T>(dto: object, controller: Controller): Promise<T> {
        //await this.ensureTrueToken()

        return new Promise<T>((resolve, reject) => {
            Axios.post(`/${controller}`, dto)
                .then(response => resolve(response.data))
                .catch(error => {
                    if (!error) reject(defaultError);
                    reject(new Error(error));
                });
        });
    }

    protected async put<T>(dto: object, controller: Controller): Promise<T> {
        //await this.ensureTrueToken()

        return new Promise<T>((resolve, reject) => {
            Axios.put(`/${controller}`, dto)
                .then(response => resolve(response.data))
                .catch(error => {
                    if (!error) reject(defaultError);
                    reject(new Error(error));
                });
        });
    }

    protected async patch<T>(dto: object, controller: Controller): Promise<T> {
        //await this.ensureTrueToken()

        return new Promise<T>((resolve, reject) => {
            Axios.patch(`/${controller}`, dto)
                .then(response => resolve(response.data))
                .catch(error => {
                    if (!error) reject(defaultError);
                    reject(new Error(error));
                });
        });
    }

    protected async patchNoBody<T>(id: number, controller: Controller): Promise<T> {
        //await this.ensureTrueToken()

        return new Promise<T>((resolve, reject) => {
            Axios.patch(`/${controller}/${id}`)
                .then(response => resolve(response.data))
                .catch(error => {
                    if (!error) reject(defaultError);
                    reject(new Error(error));
                });
        });
    }

    protected async delete(id: number, controller: Controller): Promise<void> {
        //await this.ensureTrueToken()

        return new Promise<void>((resolve, reject) => {
            Axios.delete(`/${controller}/${id}`)
                .then(() => resolve())
                .catch(error => {
                    if (!error) reject(defaultError);
                    reject(new Error(error));
                });
        });
    }
}