﻿import { JsonConvert } from "json2typescript";
import HttpClient from "@/utils/http-client";
import { DampComponentDto } from '../models/dtos/damp-component-dto';
import { Controller } from '../models/enums/controller';

export default class AssetsRepository extends HttpClient {
    jsonConvert = new JsonConvert();

    public async getDampComponent(): Promise<DampComponentDto[]> {
        return new Promise<DampComponentDto[]>((resolve, reject) => {
            this.getAll<DampComponentDto[]>(Controller.Assets)
                .then(response => resolve(this.jsonConvert.deserializeArray(response, DampComponentDto)))
                .catch(error => {
                    reject(error);
                });
        });
    }
}