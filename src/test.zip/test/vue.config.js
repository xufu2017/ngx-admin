module.exports = {
  pwa: {
    name: 'Assets Damp Logging',
    themeColor: '#F15C76',
    msTileColor: '#F15C76',
    appleMobileWebAppCapable: 'yes',
    appleMobileWebAppStatusBarStyle: 'black',
  }
}