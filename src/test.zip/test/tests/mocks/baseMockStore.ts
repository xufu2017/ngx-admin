import Vue from "vue";
import Vuex, { Module } from "vuex";

Vue.use(Vuex);

export default abstract class BaseMockStore {
  protected abstract _instance: Module<any, any>;
  constructor() {}

  protected overrideDefault() {
    return {
      state: {},
      getters: {},
      mutations: {},
      actions: {},
    };
  }
  async getStore(customStore: any) {
    return {
      namespaced: true,
      getters: {
        ...this._instance.getters,
        ...this.overrideDefault()?.getters,
        ...customStore?.getters,
      },
      mutations: {
        ...this._instance.mutations,
        ...this.overrideDefault()?.mutations,
        ...customStore?.mutations,
      },
      actions: {
        ...this._instance.actions,
        ...this.overrideDefault()?.actions,
        ...customStore?.actions,
      },
      state: {
        ...this._instance.state,
        ...this.overrideDefault()?.state,
        ...customStore?.state,
      },
    };
  }
}