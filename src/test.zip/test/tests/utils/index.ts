import { VueConstructor } from 'vue/types/vue';
import Vuex from 'vuex'
import { shallowMount, createLocalVue, Wrapper, ThisTypedShallowMountOptions,  RouterLinkStub } from '@vue/test-utils';
import Vue from 'vue';

export const mountComponentWithStore=<V extends Vue>(
    component: VueConstructor<V>,
    storeOptions: object = {},
    mountOptions: ThisTypedShallowMountOptions<V> = {}
  ): Wrapper<V> => {
    const localVue = createLocalVue();
    localVue.use(Vuex);
  
    const store = new Vuex.Store({
      ...storeOptions
    });
  
    return shallowMount(component, {
      store,
      localVue,
      ...mountOptions
    })
  };