import { mountComponentWithStore } from "../../../utils";
import Header from "@/components/shared/Header.vue";
import DampReportMockStore from "../../../mocks/dampReportStore";

describe("Header.vue", () => {
  it("should have site header title", async () => {
    const store = {
      modules: {
        dampReport: await new DampReportMockStore().getStore(null),
      },
    };
    const wrapper = mountComponentWithStore(Header, store);
    let header = wrapper.find("header");
    expect(header.element.getAttribute("class")).toBe("site-header");

    let h1 = wrapper.find("h1");
    expect(h1.element.textContent).toEqual("Damp Reporting");
  });

  it("toggleNavigation event", async () => {
    const store = {
      modules: {
        dampReport: await new DampReportMockStore().getStore(null),
      },
    };

    const toggleNavigation = jest.spyOn(
      store.modules.dampReport.actions,
      "toggleNavigation"
    );
    const wrapper = mountComponentWithStore(Header, store);

    const buttons = wrapper.findAll("button");

    await buttons.at(0).trigger("click");

    expect(toggleNavigation).toHaveBeenCalled();
  });

  it("togglePhotosPanel event", async () => {
    const store = {
      modules: {
        dampReport: await new DampReportMockStore().getStore(null),
      },
    };

    const togglePhotosPanel = jest.spyOn(
      store.modules.dampReport.actions,
      "togglePhotosPanel"
    );
    const wrapper = mountComponentWithStore(Header, store);

    const buttons = wrapper.findAll("button");

    await buttons.at(1).trigger("click");

    expect(togglePhotosPanel).toHaveBeenCalled();
  });
});
