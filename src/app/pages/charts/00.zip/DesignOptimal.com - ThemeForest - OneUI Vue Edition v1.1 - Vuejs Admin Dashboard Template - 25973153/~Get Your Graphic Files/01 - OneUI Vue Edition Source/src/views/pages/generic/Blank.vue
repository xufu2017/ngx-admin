<template>
  <div>
    <!-- Hero -->
    <base-page-heading title="Blank" subtitle="That feeling of delight when you start your awesome new project!">
      <template #extra>
        <b-breadcrumb class="breadcrumb-alt">
          <b-breadcrumb-item href="javascript:void(0)">Generic</b-breadcrumb-item>
          <b-breadcrumb-item active>Blank</b-breadcrumb-item>
        </b-breadcrumb>
      </template>
    </base-page-heading>
    <!-- END Hero -->

    <!-- Page Content -->
    <div class="content">
      <h2 class="content-heading">Your Content <small>Subtitle</small></h2>
      <p>
        ...
      </p>
    </div>
    <!-- END Page Content -->
  </div>
</template>
