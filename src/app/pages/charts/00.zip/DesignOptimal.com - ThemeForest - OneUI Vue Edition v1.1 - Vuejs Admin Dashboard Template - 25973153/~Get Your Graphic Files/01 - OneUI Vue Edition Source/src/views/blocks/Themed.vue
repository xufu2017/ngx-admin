<template>
  <div>
    <!-- Hero -->
    <base-page-heading title="Block Options" subtitle="Colorful blocks to match with your design.">
      <template #extra>
        <b-breadcrumb class="breadcrumb-alt">
          <b-breadcrumb-item href="javascript:void(0)">Blocks</b-breadcrumb-item>
          <b-breadcrumb-item active>Themed</b-breadcrumb-item>
        </b-breadcrumb>
      </template>
    </base-page-heading>
    <!-- END Hero -->

    <!-- Page Content -->
    <div class="content">
      <!-- Square Themed Blocks -->
      <h2 class="content-heading">Themed Square</h2>
      <b-row>
        <b-col md="6" xl="3">
          <base-block title="Primary" themed>
            <template #options>
              <button type="button" class="btn-block-option">
                <i class="si si-settings"></i>
              </button>
            </template>
            <p>
              Block’s content..
            </p>
          </base-block>
        </b-col>
        <b-col md="6" xl="3">
          <base-block title="Primary Light" header-class="bg-primary-light" themed>
            <template #options>
              <button type="button" class="btn-block-option">
                <i class="si si-settings"></i>
              </button>
            </template>
            <p>
              Block’s content..
            </p>
          </base-block>
        </b-col>
        <b-col md="6" xl="3">
          <base-block title="Primary Dark" header-class="bg-primary-dark" themed>
            <template #options>
              <button type="button" class="btn-block-option">
                <i class="si si-settings"></i>
              </button>
            </template>
            <p>
              Block’s content..
            </p>
          </base-block>
        </b-col>
        <b-col md="6" xl="3">
          <base-block title="Primary Darker" header-class="bg-primary-darker" themed>
            <template #options>
              <button type="button" class="btn-block-option">
                <i class="si si-settings"></i>
              </button>
            </template>
            <p>
              Block’s content..
            </p>
          </base-block>
        </b-col>
        <b-col md="6" xl="3">
          <base-block title="Success" header-class="bg-success" themed>
            <template #options>
              <button type="button" class="btn-block-option">
                <i class="si si-settings"></i>
              </button>
            </template>
            <p>
              Block’s content..
            </p>
          </base-block>
        </b-col>
        <b-col md="6" xl="3">
          <base-block title="Info" header-class="bg-info" themed>
            <template #options>
              <button type="button" class="btn-block-option">
                <i class="si si-settings"></i>
              </button>
            </template>
            <p>
              Block’s content..
            </p>
          </base-block>
        </b-col>
        <b-col md="6" xl="3">
          <base-block title="Warning" header-class="bg-warning" themed>
            <template #options>
              <button type="button" class="btn-block-option">
                <i class="si si-settings"></i>
              </button>
            </template>
            <p>
              Block’s content..
            </p>
          </base-block>
        </b-col>
        <b-col md="6" xl="3">
          <base-block title="Danger" header-class="bg-danger" themed>
            <template #options>
              <button type="button" class="btn-block-option">
                <i class="si si-settings"></i>
              </button>
            </template>
            <p>
              Block’s content..
            </p>
          </base-block>
        </b-col>
        <b-col md="6" xl="3">
          <base-block title="Gray" header-class="bg-gray" themed>
            <template #options>
              <button type="button" class="btn-block-option">
                <i class="si si-settings"></i>
              </button>
            </template>
            <p>
              Block’s content..
            </p>
          </base-block>
        </b-col>
        <b-col md="6" xl="3">
          <base-block title="Gray Dark" header-class="bg-muted" themed>
            <template #options>
              <button type="button" class="btn-block-option">
                <i class="si si-settings"></i>
              </button>
            </template>
            <p>
              Block’s content..
            </p>
          </base-block>
        </b-col>
        <b-col md="6" xl="3">
          <base-block title="Gray Darker" header-class="bg-gray-darker" themed>
            <template #options>
              <button type="button" class="btn-block-option">
                <i class="si si-settings"></i>
              </button>
            </template>
            <p>
              Block’s content..
            </p>
          </base-block>
        </b-col>
        <b-col md="6" xl="3">
          <base-block title="Black" header-class="bg-black" themed>
            <template #options>
              <button type="button" class="btn-block-option">
                <i class="si si-settings"></i>
              </button>
            </template>
            <p>
              Block’s content..
            </p>
          </base-block>
        </b-col>
        <b-col md="6" xl="3">
          <base-block title="Default" header-class="bg-default" themed>
            <template #options>
              <button type="button" class="btn-block-option">
                <i class="si si-settings"></i>
              </button>
            </template>
            <p>
              Block’s content..
            </p>
          </base-block>
        </b-col>
        <b-col md="6" xl="3">
          <base-block title="Default Light" header-class="bg-default-light" themed>
            <template #options>
              <button type="button" class="btn-block-option">
                <i class="si si-settings"></i>
              </button>
            </template>
            <p>
              Block’s content..
            </p>
          </base-block>
        </b-col>
        <b-col md="6" xl="3">
          <base-block title="Default Dark" header-class="bg-default-dark" themed>
            <template #options>
              <button type="button" class="btn-block-option">
                <i class="si si-settings"></i>
              </button>
            </template>
            <p>
              Block’s content..
            </p>
          </base-block>
        </b-col>
        <b-col md="6" xl="3">
          <base-block title="Default Darker" header-class="bg-default-darker" themed>
            <template #options>
              <button type="button" class="btn-block-option">
                <i class="si si-settings"></i>
              </button>
            </template>
            <p>
              Block’s content..
            </p>
          </base-block>
        </b-col>
        <b-col md="6" xl="3">
          <base-block title="Amethyst" header-class="bg-amethyst" themed>
            <template #options>
              <button type="button" class="btn-block-option">
                <i class="si si-settings"></i>
              </button>
            </template>
            <p>
              Block’s content..
            </p>
          </base-block>
        </b-col>
        <b-col md="6" xl="3">
          <base-block title="Amethyst Light" header-class="bg-amethyst-light" themed>
            <template #options>
              <button type="button" class="btn-block-option">
                <i class="si si-settings"></i>
              </button>
            </template>
            <p>
              Block’s content..
            </p>
          </base-block>
        </b-col>
        <b-col md="6" xl="3">
          <base-block title="Amethyst Dark" header-class="bg-amethyst-dark" themed>
            <template #options>
              <button type="button" class="btn-block-option">
                <i class="si si-settings"></i>
              </button>
            </template>
            <p>
              Block’s content..
            </p>
          </base-block>
        </b-col>
        <b-col md="6" xl="3">
          <base-block title="Amethyst Darker" header-class="bg-amethyst-darker" themed>
            <template #options>
              <button type="button" class="btn-block-option">
                <i class="si si-settings"></i>
              </button>
            </template>
            <p>
              Block’s content..
            </p>
          </base-block>
        </b-col>
        <b-col md="6" xl="3">
          <base-block title="City" header-class="bg-city" themed>
            <template #options>
              <button type="button" class="btn-block-option">
                <i class="si si-settings"></i>
              </button>
            </template>
            <p>
              Block’s content..
            </p>
          </base-block>
        </b-col>
        <b-col md="6" xl="3">
          <base-block title="City Light" header-class="bg-city-light" themed>
            <template #options>
              <button type="button" class="btn-block-option">
                <i class="si si-settings"></i>
              </button>
            </template>
            <p>
              Block’s content..
            </p>
          </base-block>
        </b-col>
        <b-col md="6" xl="3">
          <base-block title="City Dark" header-class="bg-city-dark" themed>
            <template #options>
              <button type="button" class="btn-block-option">
                <i class="si si-settings"></i>
              </button>
            </template>
            <p>
              Block’s content..
            </p>
          </base-block>
        </b-col>
        <b-col md="6" xl="3">
          <base-block title="City Darker" header-class="bg-city-darker" themed>
            <template #options>
              <button type="button" class="btn-block-option">
                <i class="si si-settings"></i>
              </button>
            </template>
            <p>
              Block’s content..
            </p>
          </base-block>
        </b-col>
        <b-col md="6" xl="3">
          <base-block title="Flat" header-class="bg-flat" themed>
            <template #options>
              <button type="button" class="btn-block-option">
                <i class="si si-settings"></i>
              </button>
            </template>
            <p>
              Block’s content..
            </p>
          </base-block>
        </b-col>
        <b-col md="6" xl="3">
          <base-block title="Flat Light" header-class="bg-flat-light" themed>
            <template #options>
              <button type="button" class="btn-block-option">
                <i class="si si-settings"></i>
              </button>
            </template>
            <p>
              Block’s content..
            </p>
          </base-block>
        </b-col>
        <b-col md="6" xl="3">
          <base-block title="Flat Dark" header-class="bg-flat-dark" themed>
            <template #options>
              <button type="button" class="btn-block-option">
                <i class="si si-settings"></i>
              </button>
            </template>
            <p>
              Block’s content..
            </p>
          </base-block>
        </b-col>
        <b-col md="6" xl="3">
          <base-block title="Flat Darker" header-class="bg-flat-darker" themed>
            <template #options>
              <button type="button" class="btn-block-option">
                <i class="si si-settings"></i>
              </button>
            </template>
            <p>
              Block’s content..
            </p>
          </base-block>
        </b-col>
        <b-col md="6" xl="3">
          <base-block title="Modern" header-class="bg-modern" themed>
            <template #options>
              <button type="button" class="btn-block-option">
                <i class="si si-settings"></i>
              </button>
            </template>
            <p>
              Block’s content..
            </p>
          </base-block>
        </b-col>
        <b-col md="6" xl="3">
          <base-block title="Modern Light" header-class="bg-modern-light" themed>
            <template #options>
              <button type="button" class="btn-block-option">
                <i class="si si-settings"></i>
              </button>
            </template>
            <p>
              Block’s content..
            </p>
          </base-block>
        </b-col>
        <b-col md="6" xl="3">
          <base-block title="Modern Dark" header-class="bg-modern-dark" themed>
            <template #options>
              <button type="button" class="btn-block-option">
                <i class="si si-settings"></i>
              </button>
            </template>
            <p>
              Block’s content..
            </p>
          </base-block>
        </b-col>
        <b-col md="6" xl="3">
          <base-block title="Modern Darker" header-class="bg-modern-darker" themed>
            <template #options>
              <button type="button" class="btn-block-option">
                <i class="si si-settings"></i>
              </button>
            </template>
            <p>
              Block’s content..
            </p>
          </base-block>
        </b-col>
        <b-col md="6" xl="3">
          <base-block title="Smooth" header-class="bg-smooth" themed>
            <template #options>
              <button type="button" class="btn-block-option">
                <i class="si si-settings"></i>
              </button>
            </template>
            <p>
              Block’s content..
            </p>
          </base-block>
        </b-col>
        <b-col md="6" xl="3">
          <base-block title="Smooth Light" header-class="bg-smooth-light" themed>
            <template #options>
              <button type="button" class="btn-block-option">
                <i class="si si-settings"></i>
              </button>
            </template>
            <p>
              Block’s content..
            </p>
          </base-block>
        </b-col>
        <b-col md="6" xl="3">
          <base-block title="Smooth Dark" header-class="bg-smooth-dark" themed>
            <template #options>
              <button type="button" class="btn-block-option">
                <i class="si si-settings"></i>
              </button>
            </template>
            <p>
              Block’s content..
            </p>
          </base-block>
        </b-col>
        <b-col md="6" xl="3">
          <base-block title="Smooth Darker" header-class="bg-smooth-darker" themed>
            <template #options>
              <button type="button" class="btn-block-option">
                <i class="si si-settings"></i>
              </button>
            </template>
            <p>
              Block’s content..
            </p>
          </base-block>
        </b-col>
      </b-row>
      <!-- END Square Themed Blocks -->

      <!-- Rounded Themed Blocks -->
      <h2 class="content-heading">Themed Rounded</h2>
      <b-row>
        <b-col md="6" xl="3">
          <base-block title="Primary" themed>
            <template #options>
              <button type="button" class="btn-block-option">
                <i class="si si-settings"></i>
              </button>
            </template>
            <p>
              Block’s content..
            </p>
          </base-block>
        </b-col>
        <b-col md="6" xl="3">
          <base-block title="Primary Light" header-class="bg-primary-light" themed rounded>
            <template #options>
              <button type="button" class="btn-block-option">
                <i class="si si-settings"></i>
              </button>
            </template>
            <p>
              Block’s content..
            </p>
          </base-block>
        </b-col>
        <b-col md="6" xl="3">
          <base-block title="Primary Dark" header-class="bg-primary-dark" themed rounded>
            <template #options>
              <button type="button" class="btn-block-option">
                <i class="si si-settings"></i>
              </button>
            </template>
            <p>
              Block’s content..
            </p>
          </base-block>
        </b-col>
        <b-col md="6" xl="3">
          <base-block title="Primary Darker" header-class="bg-primary-darker" themed rounded>
            <template #options>
              <button type="button" class="btn-block-option">
                <i class="si si-settings"></i>
              </button>
            </template>
            <p>
              Block’s content..
            </p>
          </base-block>
        </b-col>
        <b-col md="6" xl="3">
          <base-block title="Success" header-class="bg-success" themed rounded>
            <template #options>
              <button type="button" class="btn-block-option">
                <i class="si si-settings"></i>
              </button>
            </template>
            <p>
              Block’s content..
            </p>
          </base-block>
        </b-col>
        <b-col md="6" xl="3">
          <base-block title="Info" header-class="bg-info" themed rounded>
            <template #options>
              <button type="button" class="btn-block-option">
                <i class="si si-settings"></i>
              </button>
            </template>
            <p>
              Block’s content..
            </p>
          </base-block>
        </b-col>
        <b-col md="6" xl="3">
          <base-block title="Warning" header-class="bg-warning" themed rounded>
            <template #options>
              <button type="button" class="btn-block-option">
                <i class="si si-settings"></i>
              </button>
            </template>
            <p>
              Block’s content..
            </p>
          </base-block>
        </b-col>
        <b-col md="6" xl="3">
          <base-block title="Danger" header-class="bg-danger" themed rounded>
            <template #options>
              <button type="button" class="btn-block-option">
                <i class="si si-settings"></i>
              </button>
            </template>
            <p>
              Block’s content..
            </p>
          </base-block>
        </b-col>
        <b-col md="6" xl="3">
          <base-block title="Gray" header-class="bg-gray" themed rounded>
            <template #options>
              <button type="button" class="btn-block-option">
                <i class="si si-settings"></i>
              </button>
            </template>
            <p>
              Block’s content..
            </p>
          </base-block>
        </b-col>
        <b-col md="6" xl="3">
          <base-block title="Gray Dark" header-class="bg-muted" themed rounded>
            <template #options>
              <button type="button" class="btn-block-option">
                <i class="si si-settings"></i>
              </button>
            </template>
            <p>
              Block’s content..
            </p>
          </base-block>
        </b-col>
        <b-col md="6" xl="3">
          <base-block title="Gray Darker" header-class="bg-gray-darker" themed rounded>
            <template #options>
              <button type="button" class="btn-block-option">
                <i class="si si-settings"></i>
              </button>
            </template>
            <p>
              Block’s content..
            </p>
          </base-block>
        </b-col>
        <b-col md="6" xl="3">
          <base-block title="Black" header-class="bg-black" themed rounded>
            <template #options>
              <button type="button" class="btn-block-option">
                <i class="si si-settings"></i>
              </button>
            </template>
            <p>
              Block’s content..
            </p>
          </base-block>
        </b-col>
        <b-col md="6" xl="3">
          <base-block title="Default" header-class="bg-default" themed rounded>
            <template #options>
              <button type="button" class="btn-block-option">
                <i class="si si-settings"></i>
              </button>
            </template>
            <p>
              Block’s content..
            </p>
          </base-block>
        </b-col>
        <b-col md="6" xl="3">
          <base-block title="Default Light" header-class="bg-default-light" themed rounded>
            <template #options>
              <button type="button" class="btn-block-option">
                <i class="si si-settings"></i>
              </button>
            </template>
            <p>
              Block’s content..
            </p>
          </base-block>
        </b-col>
        <b-col md="6" xl="3">
          <base-block title="Default Dark" header-class="bg-default-dark" themed rounded>
            <template #options>
              <button type="button" class="btn-block-option">
                <i class="si si-settings"></i>
              </button>
            </template>
            <p>
              Block’s content..
            </p>
          </base-block>
        </b-col>
        <b-col md="6" xl="3">
          <base-block title="Default Darker" header-class="bg-default-darker" themed rounded>
            <template #options>
              <button type="button" class="btn-block-option">
                <i class="si si-settings"></i>
              </button>
            </template>
            <p>
              Block’s content..
            </p>
          </base-block>
        </b-col>
        <b-col md="6" xl="3">
          <base-block title="Amethyst" header-class="bg-amethyst" themed rounded>
            <template #options>
              <button type="button" class="btn-block-option">
                <i class="si si-settings"></i>
              </button>
            </template>
            <p>
              Block’s content..
            </p>
          </base-block>
        </b-col>
        <b-col md="6" xl="3">
          <base-block title="Amethyst Light" header-class="bg-amethyst-light" themed rounded>
            <template #options>
              <button type="button" class="btn-block-option">
                <i class="si si-settings"></i>
              </button>
            </template>
            <p>
              Block’s content..
            </p>
          </base-block>
        </b-col>
        <b-col md="6" xl="3">
          <base-block title="Amethyst Dark" header-class="bg-amethyst-dark" themed rounded>
            <template #options>
              <button type="button" class="btn-block-option">
                <i class="si si-settings"></i>
              </button>
            </template>
            <p>
              Block’s content..
            </p>
          </base-block>
        </b-col>
        <b-col md="6" xl="3">
          <base-block title="Amethyst Darker" header-class="bg-amethyst-darker" themed rounded>
            <template #options>
              <button type="button" class="btn-block-option">
                <i class="si si-settings"></i>
              </button>
            </template>
            <p>
              Block’s content..
            </p>
          </base-block>
        </b-col>
        <b-col md="6" xl="3">
          <base-block title="City" header-class="bg-city" themed rounded>
            <template #options>
              <button type="button" class="btn-block-option">
                <i class="si si-settings"></i>
              </button>
            </template>
            <p>
              Block’s content..
            </p>
          </base-block>
        </b-col>
        <b-col md="6" xl="3">
          <base-block title="City Light" header-class="bg-city-light" themed rounded>
            <template #options>
              <button type="button" class="btn-block-option">
                <i class="si si-settings"></i>
              </button>
            </template>
            <p>
              Block’s content..
            </p>
          </base-block>
        </b-col>
        <b-col md="6" xl="3">
          <base-block title="City Dark" header-class="bg-city-dark" themed rounded>
            <template #options>
              <button type="button" class="btn-block-option">
                <i class="si si-settings"></i>
              </button>
            </template>
            <p>
              Block’s content..
            </p>
          </base-block>
        </b-col>
        <b-col md="6" xl="3">
          <base-block title="City Darker" header-class="bg-city-darker" themed rounded>
            <template #options>
              <button type="button" class="btn-block-option">
                <i class="si si-settings"></i>
              </button>
            </template>
            <p>
              Block’s content..
            </p>
          </base-block>
        </b-col>
        <b-col md="6" xl="3">
          <base-block title="Flat" header-class="bg-flat" themed rounded>
            <template #options>
              <button type="button" class="btn-block-option">
                <i class="si si-settings"></i>
              </button>
            </template>
            <p>
              Block’s content..
            </p>
          </base-block>
        </b-col>
        <b-col md="6" xl="3">
          <base-block title="Flat Light" header-class="bg-flat-light" themed rounded>
            <template #options>
              <button type="button" class="btn-block-option">
                <i class="si si-settings"></i>
              </button>
            </template>
            <p>
              Block’s content..
            </p>
          </base-block>
        </b-col>
        <b-col md="6" xl="3">
          <base-block title="Flat Dark" header-class="bg-flat-dark" themed rounded>
            <template #options>
              <button type="button" class="btn-block-option">
                <i class="si si-settings"></i>
              </button>
            </template>
            <p>
              Block’s content..
            </p>
          </base-block>
        </b-col>
        <b-col md="6" xl="3">
          <base-block title="Flat Darker" header-class="bg-flat-darker" themed rounded>
            <template #options>
              <button type="button" class="btn-block-option">
                <i class="si si-settings"></i>
              </button>
            </template>
            <p>
              Block’s content..
            </p>
          </base-block>
        </b-col>
        <b-col md="6" xl="3">
          <base-block title="Modern" header-class="bg-modern" themed rounded>
            <template #options>
              <button type="button" class="btn-block-option">
                <i class="si si-settings"></i>
              </button>
            </template>
            <p>
              Block’s content..
            </p>
          </base-block>
        </b-col>
        <b-col md="6" xl="3">
          <base-block title="Modern Light" header-class="bg-modern-light" themed rounded>
            <template #options>
              <button type="button" class="btn-block-option">
                <i class="si si-settings"></i>
              </button>
            </template>
            <p>
              Block’s content..
            </p>
          </base-block>
        </b-col>
        <b-col md="6" xl="3">
          <base-block title="Modern Dark" header-class="bg-modern-dark" themed rounded>
            <template #options>
              <button type="button" class="btn-block-option">
                <i class="si si-settings"></i>
              </button>
            </template>
            <p>
              Block’s content..
            </p>
          </base-block>
        </b-col>
        <b-col md="6" xl="3">
          <base-block title="Modern Darker" header-class="bg-modern-darker" themed rounded>
            <template #options>
              <button type="button" class="btn-block-option">
                <i class="si si-settings"></i>
              </button>
            </template>
            <p>
              Block’s content..
            </p>
          </base-block>
        </b-col>
        <b-col md="6" xl="3">
          <base-block title="Smooth" header-class="bg-smooth" themed rounded>
            <template #options>
              <button type="button" class="btn-block-option">
                <i class="si si-settings"></i>
              </button>
            </template>
            <p>
              Block’s content..
            </p>
          </base-block>
        </b-col>
        <b-col md="6" xl="3">
          <base-block title="Smooth Light" header-class="bg-smooth-light" themed rounded>
            <template #options>
              <button type="button" class="btn-block-option">
                <i class="si si-settings"></i>
              </button>
            </template>
            <p>
              Block’s content..
            </p>
          </base-block>
        </b-col>
        <b-col md="6" xl="3">
          <base-block title="Smooth Dark" header-class="bg-smooth-dark" themed rounded>
            <template #options>
              <button type="button" class="btn-block-option">
                <i class="si si-settings"></i>
              </button>
            </template>
            <p>
              Block’s content..
            </p>
          </base-block>
        </b-col>
        <b-col md="6" xl="3">
          <base-block title="Smooth Darker" header-class="bg-smooth-darker" themed rounded>
            <template #options>
              <button type="button" class="btn-block-option">
                <i class="si si-settings"></i>
              </button>
            </template>
            <p>
              Block’s content..
            </p>
          </base-block>
        </b-col>
      </b-row>
      <!-- END Rounded Themed Blocks -->
    </div>
    <!-- END Page Content -->
  </div>
</template>
