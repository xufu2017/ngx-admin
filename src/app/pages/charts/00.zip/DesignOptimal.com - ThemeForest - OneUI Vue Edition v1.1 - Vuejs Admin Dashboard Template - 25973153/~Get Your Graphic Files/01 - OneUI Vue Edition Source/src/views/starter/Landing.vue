<template>
  <div>
    <!-- Hero -->
    <div class="hero bg-white">
      <div class="content content-full text-center">
        <div class="pt-5 pb-3 text-center">
          <i class="fa fa-2x fa-circle-notch text-primary"></i>
        </div>
        <h1 class="display-4 font-w700 mb-3">
          OneUI <span class="font-w300">Vue Edition</span>
        </h1>
        <p>
          This is a simple layout based page which you can use as a base for your landing, authentication, status or error pages.
        </p>
        <b-button size="sm" variant="alt-primary" class="px-4 py-2 m-2" to="/backend/dashboard" v-click-ripple>
          <i class="fa fa-fw fa-rocket mr-1"></i> Backend Page
        </b-button>
      </div>
    </div>
    <!-- END Hero -->
  </div>
</template>
