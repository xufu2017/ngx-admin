import { mountComponentWithStore } from "../../utils";
import About from "@/views/About.vue";
import flushPromises from "flush-promises";
describe('should be able to set title', () => {
    it('makes correct calls to stores on created hook', async () => {
        const mockStore = {
            modules: {
              dampReport: {
                  actions:{
                    updateTitle:jest.fn()
                  },
                  getters:{
                      title:jest.fn().mockReturnValue('test')
                  },
                  namespaced: true,
              }
            },
          };

          const wrapper = mountComponentWithStore(About, mockStore)
          await flushPromises();
          expect(mockStore.modules.dampReport.actions.updateTitle).toHaveBeenCalledTimes(1);
    });

});