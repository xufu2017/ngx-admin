import { mountComponentWithStore } from "../../utils";
import Home from "@/views/Home.vue";
import DampReportMockStore from "../../mocks/dampReportStore";
import { RouterLinkStub } from "@vue/test-utils";
import flushPromises from 'flush-promises';
describe("Home.vue", () => {
  it("should have called set title", async () => {
    const mockStore = {
      modules: {
        dampReport: await new DampReportMockStore().getStore({
            actions: {
                updateTitle: jest.fn(),
              }
        }),
      },
    };
    const wrapper = mountComponentWithStore(Home, mockStore, {
        stubs: {
          RouterLink: RouterLinkStub,
        },});

      
          await flushPromises();
          expect(mockStore.modules.dampReport.actions.updateTitle).toHaveBeenCalledTimes(1);
    // let header = wrapper.find("header");
    // expect(header.element.getAttribute("class")).toBe("site-header");

    // let h1 = wrapper.find("h1");
    // expect(h1.element.textContent).toEqual("Damp Reporting");
  });
});
