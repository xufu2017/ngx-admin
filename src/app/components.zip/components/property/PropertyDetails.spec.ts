import { PropertyDto } from "@/models/dtos/property-dto";
import { mountComponentWithStore } from "../../../utils";
import PropertyDetail from "@/components/property/PropertyDetails.vue";
import { RouterLinkStub } from "@vue/test-utils";

describe("Property detail unit test", () => {
  const mockStore = {
    modules: {
      dampReport: {
        actions: {
          updateActivePropertyCustomerTab: jest.fn(),
        },
        namespaced: true,
      },
      property: {
        actions: {
          updatePropertyDetials: jest.fn(),
        },
        namespaced: true,
      },
    },
  };

  afterEach(async () => {
    jest.clearAllMocks();
  });

  it("can be initialize", async () => {
    const wrapper = mountComponentWithStore(PropertyDetail, mockStore, {
      propsData: {
        propertyDetail: new PropertyDto(),
      },
    });
    expect(wrapper.exists()).toBeTruthy();
  });

  it("can handle property details update when click button", async () => {
    const wrapper = mountComponentWithStore(PropertyDetail, mockStore, {
      propsData: {
        propertyDetail: new PropertyDto(),
      },
    });
    jest.spyOn(wrapper.vm as any, "updatePropertyDetails");
    //expect(wrapper.find(".actions").find('button').exists())
    window.scrollTo = jest.fn();
    await wrapper
      .find(".actions")
      .find("button")
      .trigger("click");

    expect(window.scrollTo).toHaveBeenCalled();
  });

  it("should be able to remove property", async () => {
    const wrapper = mountComponentWithStore(PropertyDetail, mockStore, {
      propsData: {
        propertyDetail: new PropertyDto(),
      },
    });
    expect(
      wrapper
        .find(".selected-property")
        .find("button")
        .exists()
    );
    await wrapper
      .find(".selected-property")
      .find("button")
      .trigger("click");
    await expect(wrapper.emitted("remove-property")).toBeTruthy();
  });
});
