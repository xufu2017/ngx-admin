import { mountComponentWithStore } from "../../../utils";
import Header from "@/components/shared/Header.vue";
import DampReportMockStore from "../../../mocks/dampReportStore";

describe("Header.vue", () => {
  it("should have site header title", async () => {
    const store = {
      modules: {
        dampReport: await new DampReportMockStore().getStore(null),
      },
    };
    const wrapper = mountComponentWithStore(Header, store);
    let header = wrapper.find("header");
    expect(header.element.getAttribute("class")).toBe("site-header");

    let h1 = wrapper.find("h1");
    expect(h1.element.textContent).toEqual("Damp Reporting");
  });
});
