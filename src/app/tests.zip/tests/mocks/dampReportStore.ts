import BaseMockStore from './baseMockStore'
import { dampReportStore } from "@/store/damp-report-store";

export default class DampReportMockStore extends BaseMockStore {
    _instance = dampReportStore;
    constructor() {
      super();
    }
    overrideDefault() {
      var moduleStore = super.overrideDefault();
      moduleStore.getters = {
        title: jest.fn().mockReturnValue("Damp Reporting"),
      };
      return moduleStore;
    }
  }
  