import module from "../../../src/store";
import {identityStore} from "../../../src/store/identity-store";
import { createContextMock } from './../../utils';
const dampstore = module;
const identitymodule=identityStore;


describe("identity-store getters", () => {
  const indentityMock = {
    user: {
      firstName: "test",
      lastName: "last",
    },
    signedIn: true,
  };
  it("should be able to get user initial", async () => {
    dampstore.state.identity = indentityMock;
    expect(dampstore.getters["identity/userInitial"]).toEqual("t");
  });

  it("should be able to get user", async () => {
    dampstore.state.identity = indentityMock;
    expect(dampstore.getters["identity/user"]).toEqual(indentityMock.user);
  });

  it("should be able to get signedIn", async () => {
    dampstore.state.identity = indentityMock;
    expect(dampstore.getters["identity/signedIn"]).toEqual(true);
  });

  it("should be able to get fullName", async () => {
    dampstore.state.identity = indentityMock;
    expect(dampstore.getters["identity/fullName"]).toEqual('test last');
  });
});

describe('identity-store mutations', () => {
    it('can updateUser', async () => {
        const indentityStoreMock = {
            user: {
              firstName: "test",
              lastName: "last",
            },
            signedIn: true,
          };
          const user = {
            firstName: "testa",
            lastName: "last",
          };  
          identitymodule.mutations?.["updateUser"](indentityStoreMock,user);
          expect(indentityStoreMock.user).toBe(user);
    });

    it('can update SignedIn', async () => {
        const indentityStoreMock = {
            signedIn: false,
          };
          identitymodule.mutations?.["updateSignedIn"](indentityStoreMock,true);
          expect(indentityStoreMock.signedIn).toBe(true);
    });
});

describe('identity-store actions', () => {

    it('calls updateUser mutation when updateUser action is called  ', async () => {
        const user = {
              firstName: "test",
              lastName: "last",
            };    
            const contextMock = createContextMock();

            const action=(identitymodule as any).actions.updateUser;
            action(contextMock, user);

            expect(contextMock.commit).toHaveBeenCalledTimes(1);
            expect(contextMock.commit).toHaveBeenCalledWith("updateUser", user);
    });
    it('calls updateSignedIn mutation when updateSignedIn action is called', async () => {
 
            const contextMock = createContextMock();

            const action=(identitymodule as any).actions.updateSignedIn;
            action(contextMock, true);

            expect(contextMock.commit).toHaveBeenCalledTimes(1);
            expect(contextMock.commit).toHaveBeenCalledWith("updateSignedIn", true);
    });
});