import module from '../../../src/store'
const dampstore=module
describe('Damp module', () => {
    it('can be loaded', async () => {
        expect (dampstore).toBeTruthy()
    });
});