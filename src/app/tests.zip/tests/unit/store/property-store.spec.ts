import module from "../../../src/store";
import {propertyStore} from "../../../src/store/property-store";
import { PropertyDto } from '@/models/dtos/property-dto';
import { createContextMock } from './../../utils';
const dampModule=module;
const propertyModule=propertyStore;

describe('property-store getters', () => {
    const mock={
        propertyList: [],
        totalPages: 0,
        selectedPropertyAddress: new PropertyDto
    }
    dampModule.state.property=mock;
    it('should be able to get propetyList ', async () => {
        expect(dampModule.getters["property/propertyList"]).toHaveLength(0)
    });
    it('should be able to get selectedPropertyAddress', async () => {
        expect(dampModule.getters["property/selectedPropertyAddress"]).toEqual(new PropertyDto)
    });
    it('should be able to get totalPages', async () => {
        expect(dampModule.getters["property/totalPages"]).toEqual(0)
    });
});

describe('property-store actions', () => {
    
    it('can call fetchPropertyList', async () => {
        const contextMock = createContextMock();
        const action=(propertyModule as any).actions.fetchPropertyList;
        const propertydata=new Array<PropertyDto>(20);
        const payload=await propertydata;
        const loadMore=true
        await action(contextMock,{payload,loadMore});
        expect(contextMock.commit).toHaveBeenCalledTimes(1);
        expect(contextMock.commit).toHaveBeenCalledWith("setPropertyList", {propertydata,loadMore});
    });

    it('can call updatePropertyDetials', async () => {
        const contextMock = createContextMock();
        const action=(propertyModule as any).actions.updatePropertyDetials;
        const data=new PropertyDto;
        await action(contextMock,data);
        expect(contextMock.commit).toHaveBeenCalledTimes(1);
        expect(contextMock.commit).toHaveBeenCalledWith("updatePropertyDetials",data);
    });
});

describe('property-store mutations', () => {
    it('can set setPropertyList ', async () => {
        const updatePropertyDetials=new PropertyDto;
        const mock={selectedPropertyAddress:updatePropertyDetials}
        propertyModule.mutations?.["updatePropertyDetials"](mock.selectedPropertyAddress)
        expect(mock.selectedPropertyAddress).toBe(updatePropertyDetials)
    });
});