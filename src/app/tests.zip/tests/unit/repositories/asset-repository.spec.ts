import Axios from "axios";
import MockAdapter from "axios-mock-adapter";
import AssetsRepository from "@/repositories/assets-repository";
import { DampComponentDto } from "@/models/dtos/damp-component-dto";
import { JsonConvert } from "json2typescript";
import { Controller } from "@/models/enum";
import { DampComponentImageDto } from "@/models/dtos/damp-component-image-dto";

jest.mock("../../../src/utils/identity", () => {
  return jest.fn().mockImplementation(() => {
    return {
      getAccessToken: () => {
        return new Promise((resolve) => {
          resolve("MockAccessToken");
        });
      },
      silentSignIn: () => {
        return new Promise((resolve) => {
          resolve("MockAccessToken");
        });
      },
    };
  });
});
describe("unit test for asset repository", () => {
  const repo = new AssetsRepository();
  const mockAxios = new MockAdapter(Axios);
  const jsonConvert = new JsonConvert();
  beforeEach(async () => {
    mockAxios.reset();
    jest.clearAllMocks();
  });

  it("can save damp component photos", async () => {
    let dampcomponentImageList = new Array<DampComponentImageDto>();
    let url = "";
    const expectedResult = 2;
    mockAxios
      .onPost(`Assets/Damp/SaveDampInspectionPhotos`, dampcomponentImageList)
      .reply(function(config) {
        url = config.url ? config.url : "";
        return new Promise(function(resolve, reject) {
          resolve([200, expectedResult]);
        });
      });

    const result = await repo.saveDampComponentPhotos(dampcomponentImageList);
    await expect(url).toBe("/Assets/Damp/SaveDampInspectionPhotos");
  });

  it("can save damp component", async () => {
    let dampcomponentList = new Array<DampComponentDto>();
    let url = "";
    const username = "test";
    const assetId = 1;
    const expectedResult = 2;
    mockAxios
      .onPost(
        `Assets/Damp/SaveDampInspection/${username}/${assetId}`,
        dampcomponentList
      )
      .reply(function(config) {
        url = config.url ? config.url : "";
        return new Promise(function(resolve, reject) {
          resolve([200, expectedResult]);
        });
      });

    const result = await repo.saveDampComponent(
      dampcomponentList,
      username,
      assetId
    );
    await expect(url).toBe("/Assets/Damp/SaveDampInspection/test/1");
    expect(result).toBe(expectedResult);
  });
  
  it("can fetch the property result through the property search when result found", async () => {
    let url = "";
    const searchDto = {
      SearchCriteria: "Leeds",
      totalItems: 0,
      itemsPerPage: 8,
      currentPage: 1,
    };

    const searchList = {
      SearchCriteria: "Leeds",
      TotalItems: 0,
      ItemsPerPage: 8,
      CurrentPage: 1,
      SortDirection: "asc",
      TotalRows: 0,
      PageNumber: 1,
      PageSize: 8,
      AddressSearchViewList: [
        {
          Id: 673,
          PropertyCode: "158",
          AddressLine1: "Leeds Road/hall Lane 140/150-28/50",
          AddressLine2: "Leeds Road",
          PostCode: "BD18 1BX",
          Type: "BLOCK",
          BuildDate: "1968-01-01T00:00:00",
          Title: null,
          ContactName: "",
          ContactNumber: null,
        },
        {
          Id: 684,
          PropertyCode: "159",
          AddressLine1: "Leeds Road/hall Lane 152/162-52/74",
          AddressLine2: "Leeds Road",
          PostCode: "BD18 1BX",
          Type: "BLOCK",
          BuildDate: "1968-01-01T00:00:00",
          Title: null,
          ContactName: "",
          ContactNumber: null,
        },
      ],
    };
    mockAxios.onGet(Controller.AddressSearch).reply(function(config) {
      url = config.url ? config.url : "";
      return new Promise(function(resolve, reject) {
        resolve([200, searchList]);
      });
    });
    const result = await repo.searchProperty(searchDto);
    await expect(result.addressSearchViewList.length == 2);
    await expect(url).toBe("/Assets/Damp/AddressSearch");
  });

  it("can fetch the property result through the property search when no result found", async () => {
    const searchDto = {
      SearchCriteria: "Leeds",
      totalItems: 0,
      itemsPerPage: 8,
      currentPage: 1,
    };

    const searchList = {
      SearchCriteria: "Leeds",
      TotalItems: 0,
      ItemsPerPage: 8,
      CurrentPage: 1,
      SortDirection: "asc",
      TotalRows: 0,
      PageNumber: 1,
      PageSize: 8,
      AddressSearchViewList: [],
    };
    mockAxios.onGet(Controller.AddressSearch).reply(function(config) {
      return new Promise(function(resolve, reject) {
        resolve([200, searchList]);
      });
    });
    const result = await repo.searchProperty(searchDto);
    await expect(result.addressSearchViewList.length == 0);
  });

  it("can retrieve asset schema", async () => {
    let url = "";
    let dampcomponentList = new Array<DampComponentDto>();
    const dampcomponentdto = new DampComponentDto();
    (dampcomponentdto.id = 1),
      (dampcomponentdto.name = "test"),
      (dampcomponentdto.options = []);

    dampcomponentList.push(dampcomponentdto);

    mockAxios.onGet("/Assets/DataSchema").reply(function(config) {
      url = config.url ? config.url : "";
      return new Promise(function(resolve, reject) {
        resolve([200, jsonConvert.serialize([dampcomponentdto])]);
      });
    });

    const result = await repo.getDampComponent();

    expect(url).toBe("/Assets/DataSchema");
    expect(result[0]).toStrictEqual(dampcomponentList[0]);
  });

  it("can retrieve asset schema and handle 404", async () => {
    mockAxios.onGet("/Assets/DataSchema").reply(function(config) {
      return new Promise(function(resolve, reject) {
        resolve([404]);
      });
    });

    await expect(repo.getDampComponent()).rejects.toEqual(
      new Error("Error: Request failed with status code 404")
    );
  });
});
