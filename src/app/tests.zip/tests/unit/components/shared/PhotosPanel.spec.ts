import { mountComponentWithStore } from "../../../utils";
import PhotosPanel from "@/components/shared/PhotosPanel.vue";

describe("PhotoPanel.vue", () => {
  const mockStore = {
    modules: {
      dampReport: {
        getters: {
          visiblePhotosPanel: jest.fn(() => true),
          showPhotosPanel: jest.fn(() => true),
        },
        actions: {
          togglePhotosPanel: jest.fn().mockImplementation(() => {
          }),
        },
        namespaced: true,
      },
    },
  };

  it("can be initialized and get correct data value", () => {
    const wrapper = mountComponentWithStore(PhotosPanel, mockStore, {
      mocks: {},
    });
    expect(wrapper.exists()).toBeTruthy();
    expect((wrapper.vm as any).selectedImages.length).toBe(0);
    expect((wrapper.vm as any).visiblePhotosPanel).toBe(true);
    expect((wrapper.vm as any).showPhotosPanel).toBe(true);
  });

  it("should be able to display correct number of images on list and able to call removeImage", async () => {
    const wrapper = mountComponentWithStore(PhotosPanel, mockStore, {
      data() {
        return {
          selectedImages: Array(20)
            .fill(null)
            .map((v, i) => ({
              name: "test" + i,
            })),
        };
      },
    });
    expect(wrapper.findAll("li").length).toBe(20);
    jest.spyOn(wrapper.vm as any, "removeImage");
    wrapper
      .findAll("li")
      .at(9)
      .find("button")
      .trigger("click");
    await expect((wrapper.vm as any).removeImage).toHaveBeenCalledTimes(1);
    expect(wrapper.findAll("li").length).toBe(19);
  });

  it("event cancelPhotosPanel", async () => {
    const wrapper = mountComponentWithStore(PhotosPanel, mockStore, {
      data() {
        return {
          selectedImages: Array(20)
            .fill(null)
            .map((v, i) => ({
              name: "test" + i,
            })),
        };
      },
      mocks: {
        cancelPhotosPanel: jest.fn(),
      },
    });
    const cancelPhotosPanel = jest.fn();
    wrapper.setMethods({ cancelPhotosPanel: cancelPhotosPanel });
    wrapper
      .find(".bottom")
      .findAll("button")
      .at(0)
      .trigger("click");
    expect(cancelPhotosPanel).toBeCalled();
  });
});
