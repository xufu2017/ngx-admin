import { mountComponentWithStore } from "../../../utils";
import Navigation from "@/components/shared/Navigation.vue";
import { RouterLinkStub } from "@vue/test-utils";
describe("Navigation.vue", () => {
  const mockStore = {
    modules: {
      dampReport: {
        getters: {
          visibleNavigation: jest.fn(() => true),
          showNavigation: jest.fn(() => true),
        },
        actions: {
          toggleNavigation: jest.fn(),
        },
        namespaced: true,
      },
    },
  };

  it("can be initialized and get correct data value", () => {
    const wrapper = mountComponentWithStore(Navigation, mockStore, {
      stubs: {
        RouterLink: RouterLinkStub,
      },
    });

    expect(wrapper.exists()).toBeTruthy();
    expect(wrapper.find(".system-navigation").exists()).toBeTruthy();
    expect((wrapper.vm as any).visibleNavigation).toBe(true);
    expect((wrapper.vm as any).showNavigation).toBe(true);
  });

  it("can toggleNavigation", () => {
    const wrapper = mountComponentWithStore(Navigation, mockStore, {
      stubs: {
        RouterLink: RouterLinkStub,
      },
    });
    const toggleNavigation = jest.spyOn(
      mockStore.modules.dampReport.actions,
      "toggleNavigation"
    );

    wrapper
      .findAll("li")
      .at(0)
      .trigger("click");

    expect(toggleNavigation).toHaveBeenCalled();
  });
});
