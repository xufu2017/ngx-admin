import { PropertyDto } from '@/models/dtos/property-dto';
import { mountComponentWithStore } from "../../../utils";
import PropertyDetail from "@/components/property/PropertyDetails.vue";
import { RouterLinkStub } from "@vue/test-utils";

describe("Property detail unit test", () => {
  const mockStore = {
    modules: {
      dampReport: {
        actions: {
          updateActivePropertyCustomerTab: jest.fn(),
        },
        namespaced: true,
      },
      property:{
          actions:{
            updatePropertyDetials: jest.fn()
          },
          namespaced: true,
      }
    },
  };
  const wrapper = mountComponentWithStore(PropertyDetail,mockStore,{
      propsData:{
        propertyDetail:new PropertyDto
      }
  });
  
  afterEach(async()=>{
      wrapper.destroy();
      jest.clearAllMocks();
  })

  it('can be initialize', async () => {
      expect(wrapper.exists()).toBeTruthy()
  });

  it('can handle property details update when click button', async () => {
    jest.spyOn(wrapper.vm as any, "updatePropertyDetails");
    //expect(wrapper.find(".actions").find('button').exists())
    await wrapper.find(".actions").find('button').trigger("click");
    
    expect((wrapper.vm as any).updatePropertyDetails).toHaveBeenCalled();
    // await wrapper.find(".actions").find('.button').trigger("click");
    // expect((wrapper.vm as any).updatePropertyDetials).toHaveBeenCalled();
  });

});
