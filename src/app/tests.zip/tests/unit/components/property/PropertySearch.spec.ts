import { mount, MountOptions, Wrapper } from "@vue/test-utils";

import propertySearch from "../../../../src/components/property/PropertySearch.vue";
describe("Property search test", () => {
  type Instance = InstanceType<typeof propertySearch>;
  let mountFunction: (options?: MountOptions<Instance>) => Wrapper<Instance>;

  beforeEach(() => {
    mountFunction = (options = {}) => {
      return mount(propertySearch, options);
    };
  });

  it("should render property search", () => {
    const wrapper = mountFunction({});
    let label = wrapper.find("label");
    expect(label.element.textContent).toBe("");
    let input = wrapper.find("input");
    expect(input.element.getAttribute("type")).toBe("text");
  });
});
