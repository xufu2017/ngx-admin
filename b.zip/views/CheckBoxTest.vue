<template>
  <div>
    <p>this is test with value been set</p>
    <div>{{ formData }}</div>

    <base-checkbox-group
      v-model="formData"
      v-bind:name="name"
      v-bind:options="options"
    />
    <hr style="margin-bottom:100px"/>
    
    <p>this is test 2 with null value</p>
    <hr />
    <div>{{ formData2 }}</div>

    <base-checkbox-group
      v-model="formData2"
      v-bind:name="name2"
      v-bind:options="options2"
    />
  </div>
</template>

<script lang="ts">
import { Component, Vue } from "vue-property-decorator";
import AttributeLookupValue from "../models/attribute-lookup-value";
import BaseCheckboxGroup from "../components/forms/BaseCheckboxGroup.vue";
@Component({
  components: {
    BaseCheckboxGroup,
  },
})
export default class CheckboxPlay extends Vue {
  name = "chkboxgrp1";
  formData = "1001,22,40";
  name2 = "chkboxgrp2";
  formData2 = null;
  options: Array<AttributeLookupValue> = [
    {
      attributeLookupValueId: 1001,
      attributeLookupValueName: "Option A",
    },
    {
      attributeLookupValueId: 22,
      attributeLookupValueName: "Option B",
    },
    {
      attributeLookupValueId: 33,
      attributeLookupValueName: "Option c",
    },
    {
      attributeLookupValueId: 40,
      attributeLookupValueName: "Option D",
    },
  ];
    options2: Array<AttributeLookupValue> = [
    {
      attributeLookupValueId: 51,
      attributeLookupValueName: "Option A2",
    },
    {
      attributeLookupValueId: 52,
      attributeLookupValueName: "Option B2",
    },
    {
      attributeLookupValueId: 53,
      attributeLookupValueName: "Option c2",
    },
    {
      attributeLookupValueId: 54,
      attributeLookupValueName: "Option D2",
    },
  ];
}
</script>