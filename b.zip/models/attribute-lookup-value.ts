export default interface AttributeLookupValue {
    attributeLookupValueId: number;
    attributeLookupValueName: string;
}

export interface RecordAttributeLookupValue extends AttributeLookupValue{
    selectedValue:boolean;
}